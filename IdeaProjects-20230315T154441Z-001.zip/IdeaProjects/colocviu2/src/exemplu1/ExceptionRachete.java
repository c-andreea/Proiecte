package exemplu1;

class ExceptionRachete extends Exception {
    public ExceptionRachete(String message) {
        super(message);
    }
}