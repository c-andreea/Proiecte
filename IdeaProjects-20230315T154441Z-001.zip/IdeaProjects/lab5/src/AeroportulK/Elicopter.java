package AeroportulK;

public class Elicopter extends Aeronava{
    public String mesajSonor;

    public Elicopter(String nume, String numePilot, int nrPasageri, int nivelComvustibil, Stare stare,String mesajSonor) {
        super(nume, numePilot, nrPasageri, nivelComvustibil, stare);
        this.mesajSonor = mesajSonor;

    }
public void afisareMesaj(String mesajSonor1) {
        this.mesajSonor = mesajSonor1;

        System.out.println(mesajSonor1);
}

public String getDesc(){
        return super.getDesc() + "\nMesaj: " + mesajSonor;
}
}
