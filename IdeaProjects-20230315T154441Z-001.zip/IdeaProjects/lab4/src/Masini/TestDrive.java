package Masini;

public class TestDrive {


    public static void main(String[] args){

            String crestere = "10";
            Autovehicul dacia = new Autovehicul();
            Autovehicul audi = new Autovehicul("Audi A4", "Negru",1,10);
            Sofer Marian = new Sofer("Mihalcea", "Alexandru Marian", 22, 321056);
            audi.setSofer(Marian);
            Rezervor rez = new Rezervor(60, 20);
            audi.setRezervor(rez);
            System.out.println(audi.toString());
            rez.Golire(10);
            audi.Accelerare(crestere);
            System.out.println(audi.toString());

        }

    }

