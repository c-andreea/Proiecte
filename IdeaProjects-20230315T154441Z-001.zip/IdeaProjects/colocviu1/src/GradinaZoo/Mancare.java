package GradinaZoo;

import java.util.ArrayList;

public class Mancare {

    public String getNumem() {
        return numem;
    }

    public int getCantitate() {
        return cantitate;
    }

    public String getOra() {
        return ora;
    }

    public void setNumem(String numem) {
        this.numem = numem;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }

    public void setOra(String ora) {
        this.ora = ora;
    }

    public String numem;
    public int cantitate;
    public String ora;

public Mancare(String numem, int cantitate, String ora)
{
    this.numem = numem;
    this.cantitate = cantitate;
    this.ora = ora;
}


public String toString() {

    return "\nNume: "+numem+"\nCantitate: "+cantitate+"\nOra: "+ora;
}

}
