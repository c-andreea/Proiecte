package AeroportulK;

public class AvionPasageri extends Aeronava{

    public int numarPasageri;
    public AvionPasageri(String nume, String numePilot, int nrPasageri, int nivelComvustibil, Stare stare,int numarPasageri) {
        super(nume, numePilot, nrPasageri, nivelComvustibil, stare);
        this.numarPasageri = numarPasageri;

    }

    public void imbarcare(int persoane){
        this.numarPasageri += persoane;
    }

    public void debarcare(int persoane){
        this.numarPasageri -= persoane;

    }
    public String getDesc(){
        return super.getDesc()+"Numar Pasageri: "+this.numarPasageri;
    }
}
