package examen2019;

public abstract class Autovehicul {
    private String marca;
    private int caiPutere;

    public Autovehicul(String marca, int caiPutere) {
        this.marca = marca;
        this.caiPutere = caiPutere;
    }
    public String toString(){
        return "Marca: " + marca + "Cai putere: " + caiPutere;
    }

}
