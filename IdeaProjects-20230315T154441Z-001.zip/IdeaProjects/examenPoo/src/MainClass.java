
public class MainClass {

	public static void main(String[] args) {
		Trailer t = new Trailer();
		Autoturism a = new Autoturism("VW", 1500, 150, false);
		Microbuz m1 = new Microbuz("Mercedes", 2500, 20);	
		Microbuz m2 = new Microbuz("Renault", 2000, 10);
		
		try {
			t.adaugaAutovehicul(a);
			t.adaugaAutovehicul(m1);
			t.adaugaAutovehicul(m2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		t.detalii();
		System.out.println("Nr locuri libere: "+t.nrLocuriLibere());
		System.out.println("Nr autoturisme sport: "+t.nrAutoturismeSport());
	}

}
