package examen2022;

public class Biciclete extends Vehicule {
    private String categorie;
    public Biciclete(String marca,String culoare, int an, String categorie){
        super(marca,culoare,an);
        this.categorie = categorie;
    }

    public String toString(){
        return super.toString() + " Categorie: " + categorie;
    }
}
