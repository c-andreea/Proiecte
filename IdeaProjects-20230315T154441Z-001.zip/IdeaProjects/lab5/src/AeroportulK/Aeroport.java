package AeroportulK;
import java.util.ArrayList;
public class Aeroport {
    private final int NUMAR_MAX_AERONAVE;
private int numarActual;
public ArrayList<Aeronava> listaAeronave=new ArrayList<>();

    public Aeroport(int numar_max_aeronave) {
        NUMAR_MAX_AERONAVE = numar_max_aeronave;
    }

    public void adaugar(Aeronava aeronava){
        if(numarActual+1<=NUMAR_MAX_AERONAVE){
            listaAeronave.add(aeronava);
            numarActual++;

        }


    }

    public void eliminar(Aeronava aeronava){
        if(numarActual-1>=0){
            numarActual--;
            listaAeronave.remove(aeronava);
        }

    }
    public void getDesc(){
        System.out.println("Numar Actual Aeronave: " + numarActual);
        for(Aeronava aeronava :listaAeronave){
            if(aeronava instanceof AvionPasageri){
                System.out.println("\nAvion: pozitia " + (listaAeronave.indexOf(aeronava)+1) + aeronava.getDesc());
            }
            if(aeronava instanceof Elicopter){
                System.out.println("\nElicopter: pozitia " + (listaAeronave.indexOf(aeronava)+1) + aeronava.getDesc());
            }
            if(aeronava instanceof AvionMilitar){
                System.out.println("\nAvion Militar: pozitia " + (listaAeronave.indexOf(aeronava)+1) + aeronava.getDesc());
            }

        }
    }
}
