package GradinaZoo;

public class Delfin extends Animale{
    public Delfin(String name, String culoare, int varsta,int nrKm) {
        super(name, culoare, varsta);
        this.nrKm = nrKm;
    }
    private int nrKm;

    @Override
    public void mananca(Mancare mancare) {
        System.out.println("\n Delfinul a fost hranit"+mancare.toString());
    }

    public void inot(int km){
        nrKm += km;
        System.out.println("\n Delfinul a inotat "+km+" km");
    }
    public String toPrint() {
        return super.toPrint() + "\n NrKm: " + nrKm;
    }
}
