package tema3_6;

public class Buton implements Icomand{

    IStart functie;

    public Buton(IStart functie) {
        this.functie = functie;
    }

    @Override
    public void execute() {
        functie.start();
    }

    @Override
    public void undo() {
        functie.stop();

    }
}
