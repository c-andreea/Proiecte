package utilities;

public interface DynamicElement {
    void Update();
}
