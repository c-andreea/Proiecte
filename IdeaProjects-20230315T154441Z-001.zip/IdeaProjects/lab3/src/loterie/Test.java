package loterie;

public class Test {

    public static void main(String[] args) {
        int[] numereMele = new int[]{1, 8, 12, 28, 48, 42};
        Bilet biletulMeu = new Bilet(numereMele);

        System.out.println("Biletul meu este");
        int[] numereDePeBilet= biletulMeu.getNumere();
        Loto loto= new Loto();
        System.out.println("");
        int[] numereGenerateDeLoterie=loto.generareNumere();

        for(int i=0;i<numereGenerateDeLoterie.length;i++)
        {
            System.out.print(numereGenerateDeLoterie[i]+" ");
        }

        System.out.println("");
        int count=0;
        for (int i=0;i<numereDePeBilet.length;i++)
        {  for(int j=0;j<numereGenerateDeLoterie.length;j++)
            {
                if(numereDePeBilet[i]==numereGenerateDeLoterie[j])
                {
                    count++;
                }
            }
        }
        System.out.print("Am ghicit "+ count);
        //int[] numereGenerateDeLoterie
    }
}
