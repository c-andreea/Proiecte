package examen2019;

public class Motocicleta extends Autovehicul {
  String atas;

    public Motocicleta(String marca, int caiPutere, String atas) {
        super(marca, caiPutere);
       this.atas = atas;
    }

    @Override
    public String toString() {
        return super.toString()+ "Atas: " + atas;
    }
}

