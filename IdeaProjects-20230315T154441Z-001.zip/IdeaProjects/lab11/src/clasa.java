import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

class MyPanel extends JPanel implements ActionListener {
    private final JLabel l;
    private final JTextField tf;
    private final JButton b1;
    private final JButton b2;
    private final JButton b3;
    private final JPanel panel1;
    private final JPanel panel2;
    private int counter;
    private final Random rand;

    public MyPanel() {
        counter = 0;
        rand = new Random();

        panel1 = new JPanel();
        panel2 = new JPanel();

        l = new JLabel("Label1 ");
        tf = new JTextField("TextField1");
        panel1.add(l);
        panel1.add(tf);
        panel1.setLayout(new FlowLayout());

        b1 = new JButton("Button 1");
        b2 = new JButton("Button 2");
        b3 = new JButton("Button 3");
        panel2.add(b1);
        panel2.add(b2);
        panel2.add(b3);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(panel1);
        add(panel2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == b1) {
            counter++;
            l.setText("Button 1 was pressed " + counter + " times");
        } else if (source == b2) {
            String text = tf.getText();
            l.setText(text);
        } else if (source == b3) {
            Color color = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
            panel1.setBackground(color);
            panel2.setBackground(color);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Simple Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 120);
        frame.setContentPane(new MyPanel());
        frame.setVisible(true);
    }
}