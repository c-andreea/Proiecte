package pob6_1;

public class Worker {
    private String name;
    private CalendarWork calendar;

    public Worker(String name, CalendarWork calendar) {
        this.name = name;
        this.calendar = calendar;
    }

    public void work(String day) throws NonworkingDayException {
        for (int i = 0; i <7; i++) {
            if (calendar.getDay(i).getName().equals(day)) {
                if (calendar.getDay(i).isWorking()) {
                    System.out.println("The worker " + name + " works on " + day);
                    return;
                } else {
                    throw new NonworkingDayException("Exception: work on a non-working day in java");
                }
            }
        }
        System.out.println(day + " is not a day of the week");
    }

    public void work2(String day) {
        try {
            for (int i = 0; i <7; i++) {
                if (calendar.getDay(i).getName().equals(day)) {
                    if (calendar.getDay(i).isWorking()) {
                        System.out.println("The worker " + name + " works on " + day);
                        return;
                    } else {
                        throw new NonworkingDayException("Exception: work on a non-working day in java");
                    }
                }
            }
            System.out.println(day + " is not a day of the week");
        } catch (NonworkingDayException e) {
            System.out.println(e.getMessage());
        } finally {
            // This block will always be executed, even if an exception is thrown or caught
            System.out.println("Finally block reached");
        }
    }


}
