
public abstract class Autovehicul implements Comparable<Autovehicul>{
	private String marca;
	private int masa;
	
	public Autovehicul (String marca, int m) {
		this.marca=marca;
		masa=m;
	}
	
	public int getMasa() {
		return masa;
	}
	
	public String toString() {
		return "Marca: "+marca+" Masa: "+masa;
	}
	
	public int compareTo(Autovehicul x) {
		return marca.compareTo(x.marca);
	}
}
