import java.math.BigInteger;

public class tema_cu_boabe {

    public static void main(String[] args){
        int n=64;
        BigInteger numar= new BigInteger("2");
for(int i=1;i<=n;i++)
{    System.out.println("patratul " + i + ":  " + numar + " boabe.");
   numar=numar.multiply(new BigInteger("2"));
}

    }


}
