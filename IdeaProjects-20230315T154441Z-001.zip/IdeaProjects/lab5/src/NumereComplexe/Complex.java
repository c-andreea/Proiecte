package NumereComplexe;

import java.sql.SQLOutput;

public class Complex {


    private int parteReala;
    private int parteaImaginara;

    public Complex(int parteReala,int parteaImaginara)
    {
        this.parteReala=parteReala;
        this.parteaImaginara=parteaImaginara;
    }
    public int getParteReala() {
        return parteReala;
    }
    public int getParteaImaginara(){
        return parteaImaginara;
    }
    public void setParteReala(int parteReala) {
        this.parteReala = parteReala;
    }
    public void setParteaImaginara(int parteaImaginara){
        this.parteaImaginara=parteaImaginara;

    }
    public Complex aduna(Complex b)
    {
      return new Complex(this.parteReala+b.parteReala,this.parteaImaginara+b.parteaImaginara);
    }
    public Complex scadere(Complex b)
    {
        return new Complex(this.parteReala-b.parteReala,this.parteaImaginara-b.parteaImaginara);
    }
    public Complex inmultire(int n)

    {
        return new Complex(this.parteReala*n,this.parteaImaginara*n);
    }
    public String toString()
    {
        if(parteReala>=0)
            return  parteReala+ "+"+parteaImaginara+"i";
        else  return  parteReala+ "-"+parteaImaginara+"i";
    }

    public static void main(String[] args)
    {
        Complex a= new Complex(9,2);
        Complex b= new Complex(4,10);
        Complex suma =a.aduna(a);
        Complex scd =b.scadere(a);
        Complex inm=b.inmultire(3);
     //   System.out.println(inm);
        System.out.println(scd.toString());

      //  System.out.println(b.toString());

    }
}
