import static org.junit.Assert.*;
import org.junit.*;

public class TestAnComun {
    AnBisect anBisect = new AnBisect();

    @Test
    public void testIsAnBisect() {

        assertFalse(anBisect.isAnBisect(99));

    }
}