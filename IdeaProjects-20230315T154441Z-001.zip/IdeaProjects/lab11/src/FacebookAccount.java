import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FacebookAccount {

    private String nume;
    private int varsta;
    private String locatie;

    List<FacebookAccount> listaPrieteni = new ArrayList<>();

    public FacebookAccount(String nume, int varsta, String locatie){
        this.nume = nume;
        this.varsta = varsta;
        this.locatie = locatie;
    }

    public void setNume(String nume){
        this.nume = nume ;
    }

    public String getNume(){
        return this.nume;
    }

    public void setVarsta(int varsta){
        this.nume = nume ;
    }

    public int getVarsta(){
        return this.varsta;
    }

    public void setLocation(String loc){
        this.locatie = loc ;
    }

    public String getLocatie(){
        return this.locatie;
    }

    public void addFriend(FacebookAccount prieten){
        listaPrieteni.add(prieten);
    }

    public void removeFriend(FacebookAccount prieten){
        listaPrieteni.remove(prieten);
    }

    public void showFriends(){
        for(FacebookAccount friend : listaPrieteni){
            System.out.println(friend.toString());
        }
    }

    public String toString(){
        return "Nume: " + nume + " | Varsta: " + varsta + " | Locatie: " + locatie;
    }

    public void filterByLocation(String locatie){
        for(FacebookAccount friend : listaPrieteni){
            if(friend.locatie.equals(locatie)){
                System.out.println(friend.toString());
            }
        }
    }

    public void sortByNume(){

        Comparator<FacebookAccount> ordineAlfabetica = new Comparator<FacebookAccount>() {
            @Override
            public int compare(FacebookAccount o1, FacebookAccount o2) {
                return o1.getNume().compareTo(o2.getNume());
            }
        };

        Collections.sort(listaPrieteni, ordineAlfabetica);

        for(FacebookAccount friend : listaPrieteni){
            System.out.println(friend.toString());
        }

    }

}
