package utilities;

import java.awt.geom.Area;

public interface CollisionalShape {
    Area GetCollisionArea();
}
