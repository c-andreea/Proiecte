package loterie;

public class Bilet {

private int[] numere;

public Bilet(int[] numere)
{
    this.numere=numere;

}

public int[] getNumere()
    {
        for(int i=0;i<numere.length;i++)
        {
            System.out.print(numere[i]+ " ");
        }
        return numere;
    }

}
