package Restaurant;

public class Test {

    public static void main(String[] args) {

        FelPrincipal preparat1=new FelPrincipal("20","Tocanita","romanesc",290,"porc", FelPrincipal.Glutten.nu);
        FelPrincipal preparat2=new FelPrincipal("30","Ciorba","romanesc",222,"gaina", FelPrincipal.Glutten.da);
        Bauturi preparat3=new Bauturi("50","ceva nume","franc",400, Bauturi.Tip.ALCOOLICA);

        Bucatar bucatar1=new Bucatar("Ion",20,"strada1");
        Bucatar bucatar2=new Bucatar("Ion2",30,"strada2");
        Meniu meniu=new Meniu();
        meniu.adaugaFelPrincipal( preparat1);
        meniu.adaugaFelPrincipal(preparat2);
        meniu.adaugaBauturi(preparat3);

        bucatar1.adaugaPreparat(preparat1);
        bucatar1.adaugaPreparat(preparat2);
        bucatar1.toPrint();

        meniu.toPrint();
        bucatar1.serveste(preparat1);
        bucatar1.toPrint();


}
}
