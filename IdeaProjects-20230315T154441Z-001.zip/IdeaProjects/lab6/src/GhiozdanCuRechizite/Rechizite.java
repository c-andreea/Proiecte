package GhiozdanCuRechizite;

public abstract class Rechizite {
    protected String eticheta;

    public Rechizite(String eticheta)
    {
        this.eticheta = eticheta;
    }
    public abstract String getNume();
}
