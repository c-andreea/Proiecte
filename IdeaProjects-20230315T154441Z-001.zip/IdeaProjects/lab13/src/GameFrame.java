import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class GameFrame extends JFrame{ //ca sa putem trata game frame-ul nostru ca un jframe normal
	
	GamePanel panel;
	
	public GameFrame(){
		panel = new GamePanel();
		this.add(panel);
		this.setTitle("Colocviu");
		this.setResizable(false);
		this.setBackground(Color.white);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //cand apasam pe X se inchide jocul
		this.pack(); //va ajusta fereastra conform gamePanelului
		this.setVisible(true);
		this.setLocationRelativeTo(null); //ca sa apara in mijlocul ecranului
		
	}

}
