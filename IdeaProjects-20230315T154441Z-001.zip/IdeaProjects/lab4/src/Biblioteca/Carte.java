package Biblioteca;

public class Carte {

    private Autor autor;


    private String numarCarte;
    private String titlu;
    private char status;
    private int anulPublicarii;
    private String editura;

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }

public Carte(String numarCarte,String titlu, char status,int anulPublicarii, String editura)
{
    this.numarCarte=numarCarte;
    this.titlu=titlu;
    this.status=status;
    this.anulPublicarii=anulPublicarii;
    this.editura=editura;
}
    public String getNumarCarte() {
        return numarCarte;
    }

    public String getTitlu() {
        return titlu;
    }

    public char getStatus() {
        return status;
    }

    public int getAnulPublicarii() {
        return anulPublicarii;
    }

    public String getEditura() {
        return editura;
    }

    public void setNumarCarte(String numarCarte) {
        this.numarCarte = numarCarte;
    }

    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public void setAnulPublicarii(int anulPublicarii) {
        this.anulPublicarii = anulPublicarii;
    }

    public void setEditura(String editura) {
        this.editura = editura;
    }
    public void updateStatus() {
        if(getStatus() == 'D')
            status = 'I';
        else
            status = 'D';

    }

    public String checkStatus() {
        if(getStatus() == 'A')
            return "Disponibila";
        else
            return "Indisponibila";

    }
    public String toString() {
        return "ID : " + getNumarCarte() + " Titlu : " + getTitlu()  +" Anul publicarii "+getAnulPublicarii()+" Editura "+getEditura()+ " Status : " + checkStatus() +" Autorul este: "+ this.autor;
    }

}
