package examen2020;

public class Microbuz extends Autovehicule {
    private int nrLocuri;

    public Microbuz(String marca, int masa, int nrLocuri) {
        super(marca, masa);
        this.nrLocuri = nrLocuri;

    }
    public String toString() {
        return "Microbuz: "+super.toString()+" nr. locuri: "+nrLocuri;
    }
}

