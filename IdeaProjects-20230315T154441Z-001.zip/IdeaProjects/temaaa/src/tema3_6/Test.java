package tema3_6;

public class Test {
    public static void Porneste(IStart functie){

       Buton buton = new Buton(functie);

        buton.execute();
        buton.undo();
    }
    public static void SetVolum(IRadio functie){
        Buton buton = new Buton(functie);

        buton.execute();
        functie.connect();
        functie.up();
        functie.down();
        functie.up();
        functie.down();
        functie.up();
        functie.up();
functie.disconnect();
        buton.undo();
    }
    public static void SetCal(ISchimba functie){
        Buton buton = new Buton(functie);

        buton.execute();

        functie.Tup();
        functie.Tdown();
        functie.Tdown();
        buton.undo();
    }
    public static void SetCom(Icomand comand){
        comand.execute();
        comand.undo();
    }
    public static void main(String[] args){

        IStart masina=new Masina("BMW","CJ 05 ABC");
        Porneste(masina);
        System.out.println();
        IRadio radio = new Radio("radio",10);
        SetVolum(radio);
        System.out.println();
        ISchimba caldura = new Caldura("caldura",3);
        SetCal( caldura);
        System.out.println();
        Icomand comand = new Buton(radio);
        SetCom(comand);

    }

}
