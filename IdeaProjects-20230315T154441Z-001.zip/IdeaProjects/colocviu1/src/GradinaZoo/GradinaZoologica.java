package GradinaZoo;

import java.util.ArrayList;

public class GradinaZoologica {

    ArrayList<Animale> listaAnimaleDinGradina=new ArrayList();
    public int nrAnimaleDinGradina=0;

    public void agregar(Animale animale){

        listaAnimaleDinGradina.add(animale);
        nrAnimaleDinGradina++;

}

public void toPrint(){
        System.out.println("Numar de animale: " + nrAnimaleDinGradina);
        for(Animale animale : listaAnimaleDinGradina)
        {
            if(animale instanceof Pinguin){
                System.out.println((listaAnimaleDinGradina.indexOf(animale)+1)+animale.toPrint());
            }
            if(animale instanceof Delfin){
                System.out.println((listaAnimaleDinGradina.indexOf(animale)+1)+animale.toPrint());
            }
            if(animale instanceof UrsPanda){
                System.out.println((listaAnimaleDinGradina.indexOf(animale)+1)+animale.toPrint());
            }

        }

}
}
