package Restaurant;

public class Bauturi extends Preparat{
    public Bauturi(String id, String name, String specific,int cantitate,Tip tip) {

        super(id, name, specific);
        this.cantitate=cantitate;
        this.tip=tip;

    }

    enum Tip{
        ALCOOLICA,
        NEALCOOLICA;
    }

    public void alcool() {this.tip=Tip.ALCOOLICA;}
    public void neacool() {this.tip=Tip.NEALCOOLICA;}

    Tip tip;
    public int cantitate;

    public String toPrint(){
        return super.toPrint()+"\nCantitate: "+cantitate+"\nTip: "+tip;
    }

}
