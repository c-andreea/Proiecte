package tema3_6;

public interface ISchimba extends IStart{
    void Tup();
    void Tdown();
}
