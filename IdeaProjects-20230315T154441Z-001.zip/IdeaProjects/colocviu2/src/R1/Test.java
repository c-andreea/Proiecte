package R1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.util.Collections;
import java.util.List;

public class Test {
    private static Gara gara = new Gara("Waterloo Station");

    public static void main(String[] args) {
        Tren tren1 = new Tren("Manchester", LocalTime.of(9, 0), "W1M");
        Tren tren2 = new Tren("Liverpool", LocalTime.of(15, 45), "W5L");
        Tren tren3 = new Tren("Bristol", LocalTime.of(12, 15), "W3B");
        Tren tren4 = new Tren("Southampton", LocalTime.of(14, 0), "W4S");

        Tren tren5 = new Tren("Brighton", LocalTime.of(10, 30), "W2B");
        gara.adaugaTren(tren1);
        gara.adaugaTren(tren2);
        gara.adaugaTren(tren3);
        gara.adaugaTren(tren4);
        gara.adaugaTren(tren5);

        SwingUtilities.invokeLater(new Test()::createAndShowGUI);
    }

    private void createAndShowGUI() {
        // Create UI elements
        JLabel labelCodUnic = new JLabel("Cod unic:");
        JTextField textFieldCodUnic = new JTextField(10);
        JButton buttonCauta = new JButton("Cauta");
        JLabel labelResult = new JLabel();

        // Add elements to layout
        JPanel panelCodUnic = new JPanel();
        panelCodUnic.add(labelCodUnic);
        panelCodUnic.add(textFieldCodUnic);
        panelCodUnic.add(buttonCauta);

        JFrame frame = new JFrame("Gara");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        frame.add(panelCodUnic);
        frame.add(labelResult);
        frame.pack();
        frame.setVisible(true);

        // Add event handler for search button
        buttonCauta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codUnic = textFieldCodUnic.getText();
                try {
                    List<Tren> trenuri = gara.cautaTren(codUnic);
                    Collections.sort(trenuri, (t1, t2) -> t1.getOraPlecarii().compareTo(t2.getOraPlecarii()));
                    StringBuilder stringBuilder = new StringBuilder();
                    for (Tren tren : trenuri) {
                        stringBuilder.append("- Trenul cu destinatia " + tren.getDestinatie() + " si codul unic " + tren.getCodUnic() + " pleaca la ora " + tren.getOraPlecarii() + "\n");
                    }
                    labelResult.setText(stringBuilder.toString()); //add this line here
                } catch (TrenulNuExistaException ex) {
                    System.out.println(ex.getMessage());
                    labelResult.setText("Trenul nu a fost gasit.");
                }
            }
        });
    }
}