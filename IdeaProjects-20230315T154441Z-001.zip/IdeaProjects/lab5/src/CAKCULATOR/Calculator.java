package CAKCULATOR;

import java.io.*;
import java.lang.*;
import java.lang.Math;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.math.BigInteger;


public class Calculator {


    public static void main(String[] args) throws FileNotFoundException {
        BigInteger rezultat;
    File file=new File("C:\\Users\\andre\\IdeaProjects\\lab5\\src\\CAKCULATOR\\Numere.txt");
    Scanner scan=new Scanner(file);
String num1="";
    while(scan.hasNextLine())
    {  num1=num1.concat(scan.nextLine());}
  //      System.out.println(num1);
        BigInteger numar1= new BigInteger(num1);

        File file1=new File("C:\\Users\\andre\\IdeaProjects\\lab5\\src\\CAKCULATOR\\Numar2.txt");
        Scanner scan1=new Scanner(file1);
        String num2="";
        while(scan1.hasNextLine())
            num2=num2.concat(scan1.nextLine());
      //  System.out.println(num2);

        BigInteger numar2=new BigInteger(num2);
       // System.out.println(numar2);


        Scanner operatie=new Scanner(System.in);
        String retinOperatia="";
        retinOperatia=retinOperatia.concat(operatie.nextLine());
        //System.out.println(retinOperatia);

        Date ziuaDeAzi=new Date();
        SimpleDateFormat dataForm=new SimpleDateFormat("Y-MM-dd-hh-mm");
       // System.out.println(dataForm.format(ziuaDeAzi));

        String fisierDeIesire="";

        switch (retinOperatia)
        {
            case "java program aduna":
                fisierDeIesire= "Rezultat-aduna-"+dataForm.format(ziuaDeAzi)+".txt";
                rezultat=numar1.add(numar2);
                String rez=rezultat.toString();
                try{
                    BufferedWriter scrie=new BufferedWriter(new FileWriter(fisierDeIesire));
                    scrie.write(rez);
                    scrie.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                break;
            case "java program scade":
                fisierDeIesire= "Rezultat-scade-"+dataForm.format(ziuaDeAzi)+".txt";
                rezultat=numar1.subtract(numar2);
                String rez1=rezultat.toString();
                try{
                    BufferedWriter scrie=new BufferedWriter(new FileWriter(fisierDeIesire));
                    scrie.write(rez1);
                    scrie.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                break;
            case "java program imparte":
                fisierDeIesire= "Rezultat-imparte-"+dataForm.format(ziuaDeAzi)+".txt";
                rezultat=numar1.divide(numar2);
                String rez2=rezultat.toString();
                try{
                    BufferedWriter scrie=new BufferedWriter(new FileWriter(fisierDeIesire));
                    scrie.write(rez2);
                    scrie.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } break;
            case "java program mod":
                fisierDeIesire= "Rezultat-mod-"+dataForm.format(ziuaDeAzi)+".txt";
                rezultat=numar1.mod(numar2);
                String rez3=rezultat.toString();
                try{
                    BufferedWriter scrie=new BufferedWriter(new FileWriter(fisierDeIesire));
                    scrie.write(rez3);
                    scrie.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                break;
            case "java program inmuteste":
                fisierDeIesire= "Rezultat-inmuteste-"+dataForm.format(ziuaDeAzi)+".txt";
                rezultat=numar1.multiply(numar2);
                String rez4=rezultat.toString();
                try{
                    BufferedWriter scrie=new BufferedWriter(new FileWriter(fisierDeIesire));
                    scrie.write(rez4);
                    scrie.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } break;



        }


    }

}
