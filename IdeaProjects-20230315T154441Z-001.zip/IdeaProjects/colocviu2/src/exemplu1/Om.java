package exemplu1;

class Om extends Angajati {
    public Om(String nume, int varsta) {
        super(nume, varsta, "om");
    }
}
