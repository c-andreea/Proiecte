package Restaurant;

import java.util.ArrayList;

public class Meniu  {

public int numarDePreparatefel=0;
public int numarDePreparatebaut=0;


    ArrayList<Preparat> preparateExistente = new ArrayList<>();

    public void adaugaFelPrincipal(FelPrincipal principal) {
      preparateExistente.add(principal);
numarDePreparatefel++;
    }
public void adaugaBauturi(Bauturi bauturi) {
        preparateExistente.add(bauturi);
        numarDePreparatebaut++;


}

public void toPrint() {

    System.out.println("numarul de feluri principale este de :"+numarDePreparatefel+"\n");
    System.out.println("numarul de bauturi este de :"+numarDePreparatebaut+"\n");
        for (Preparat p : preparateExistente){
            if( p instanceof FelPrincipal)
            {
                System.out.println("\n"+(preparateExistente.indexOf(p)+1) +p.toPrint());}
else if( p instanceof Bauturi ){
                System.out.println("\n"+(preparateExistente.indexOf(p)+1) +p.toPrint()); }
        }

}

}
