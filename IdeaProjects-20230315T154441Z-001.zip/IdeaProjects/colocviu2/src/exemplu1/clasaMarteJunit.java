package exemplu1;

public class clasaMarteJunit {
}
