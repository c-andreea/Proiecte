public class Exemplu1 {
    public static void main(String[] args)
    {
        String nume="Mickey Mouse";
        String altNume="Mickey Mouse";
        System.out.println(nume== altNume);

        String var1="Mickey";
        String var2="Mouse";
        String concatenareNume=var1+" "+var2;
        System.out.println("ref in memorie: " + nume== concatenareNume);

        System.out.println("equals: "+nume.equals(concatenareNume));


    }


}
