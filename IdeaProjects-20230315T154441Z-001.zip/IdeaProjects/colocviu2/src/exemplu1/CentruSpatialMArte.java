package exemplu1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

class CentrulSpatialMarte {
    private List<Aeronave> aeronave;
    private List<Angajati> angajati;
    private List<Piloti> piloti;

    public CentrulSpatialMarte() {
        aeronave = new ArrayList<>();
        angajati = new ArrayList<>();
        piloti = new ArrayList<>();
    }

    public void adaugaAeronava(Aeronave aeronava) {
        aeronave.add(aeronava);
    }

    public void adaugaAngajat(Angajati angajat) {
        angajati.add(angajat);
    }

    public void adaugaPilot(Piloti pilot) {
        piloti.add(pilot);
    }

    public List<Aeronave> getAeronave() {
        return aeronave;
    }

    public List<Angajati> getAngajati() {
        return angajati;
    }

    public List<Piloti> getPiloti() {
        return piloti;
    }

    public void inregistreazaPlecareRachete(RacheteApolo racheta, LocalDateTime dataPlecare) {
        racheta.setDataPlecare(dataPlecare);
    }

    public List<RacheteApolo> getRachetePlecateDupaData(LocalDateTime dataCautare) throws ExceptionRachete {
        List<RacheteApolo> rachetePlecate = new ArrayList<>();
        for (Aeronave aeronava : aeronave) {
            if (aeronava instanceof RacheteApolo) {
                RacheteApolo racheta = (RacheteApolo) aeronava;
                if (racheta.getDataPlecare().isAfter(dataCautare)) {
                    rachetePlecate.add(racheta);
                }
            }
        }
        if (rachetePlecate.size() == 0) {
            throw new ExceptionRachete("Nu exista rachete care sa fi plecat dupa data specificata.");
        }
        return rachetePlecate;
    }
}
