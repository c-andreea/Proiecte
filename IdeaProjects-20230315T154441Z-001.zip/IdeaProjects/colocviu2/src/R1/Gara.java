package R1;

import java.util.ArrayList;
import java.util.List;

public class Gara {
    private String nume;
    private List<Tren> trenuri;

    public Gara(String nume) {
        this.nume = nume;
        this.trenuri = new ArrayList<>();
    }

    public String getNume() {
        return nume;
    }

    public List<Tren> getTrenuri() {
        return trenuri;
    }

    public void adaugaTren(Tren tren) {
        trenuri.add(tren);
    }
    public List<Tren> cautaTren(String codUnic) throws TrenulNuExistaException {

        List<Tren> trenuriGasite = new ArrayList<>();
        for (Tren tren : trenuri) {
            if (tren.getCodUnic().contains(codUnic)) {
                trenuriGasite.add(tren);
            }
        }
        if (trenuriGasite.isEmpty()) {
            throw new TrenulNuExistaException("Trenul cu codul unic " + codUnic + " nu a fost gasit in gara " );
        }
        return trenuriGasite;
    }
}

