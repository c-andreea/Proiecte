import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GamePanel extends JPanel implements Runnable{
	 JPanel panel1 = new JPanel();
	 JPanel panel2 = new JPanel();

	 JLabel l = new JLabel ("Label1 ");
	 JTextField tf = new JTextField("TextField1");
	
	public void run() {
		 panel1.add(l);
		 panel1.add(tf);
		 panel1.setLayout(new FlowLayout());
	}

}
