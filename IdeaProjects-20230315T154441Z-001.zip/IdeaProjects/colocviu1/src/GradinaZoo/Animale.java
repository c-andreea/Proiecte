package GradinaZoo;

import java.util.ArrayList;

public abstract class Animale {

    public String getName() {
        return name;
    }

    public String getCuloare() {
        return culoare;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    protected String name;
    protected String culoare;
    protected int varsta;

    public Animale(String name, String culoare, int varsta)
    {
        this.name = name;
this. culoare = culoare;
this.varsta = varsta;
    }

    public abstract void mananca(Mancare mancare);


    public String toPrint(){
        return "\nNUme: "+name+"\nCuloare: "+culoare+"\nVarsta: "+varsta;

    }
}
