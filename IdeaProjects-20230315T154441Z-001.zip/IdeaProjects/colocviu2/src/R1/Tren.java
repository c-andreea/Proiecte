package R1;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Tren {
    private List<Tren> trenuri = new ArrayList<>();
    private String destinatie;
    private LocalTime oraPlecarii;
    private String codUnic;

    public Tren(String destinatie, LocalTime oraPlecarii, String codUnic) {
        this.destinatie = destinatie;
        this.oraPlecarii = oraPlecarii;
        this.codUnic = codUnic;
    }

    public String getDestinatie() {
        return destinatie;
    }

    public LocalTime getOraPlecarii() {
        return oraPlecarii;
    }

    public String getCodUnic() {
        return codUnic;
    }

}
