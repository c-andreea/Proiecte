package AeroportulK;

public class Ruta {

    public String orasPlecare;
    public String orasDest;
    public int nrKm;

    public Ruta(String orasPlecare, String orasDest, int nr){
        this.orasPlecare = orasPlecare;
        this.orasDest = orasDest;
        this.nrKm = nr;

    }

    public String toString(){
        return "Oras plecare "+orasPlecare+" Oras destinatie: "+orasDest+" numar de km "+nrKm;

    }

}
