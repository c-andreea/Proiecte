package examen2022;

import java.util.Scanner;

public class Parcare {
    private int nrZone;
    private Zone[] zone;

    public Parcare()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduceti numarul de zone: ");
        this.nrZone = sc.nextInt();
        zone = new Zone[nrZone+1];
        for(int i = 1; i<=this.nrZone; i++)
        {
            System.out.println("Introduceti numarul de locuri din zona " + i);
            int temp = sc.nextInt();
            zone[i] = new Zone(temp);
        }
        sc.close();

    }
    public void parcheaza(Vehicule x,int z)throws Exception{
        zone[z].addVehicule(x);
    }
    public void nrBiciclete(int an, int z) {
      zone[z].nrBiciclete(an);
    }

}
