import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Verificare {
	
	@Test
	public void esteAnBisectTest() {
		DestinatieDorita test = new DestinatieDorita();
		assertTrue(DestinatieDorita.DestinatieDorita("Munchen",new Tren("Munchen",12,30,"AC1")));
	}

}
