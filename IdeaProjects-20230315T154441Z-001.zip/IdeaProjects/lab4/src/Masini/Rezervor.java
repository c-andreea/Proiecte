package Masini;

public class Rezervor {
    private int capacitate_max;
    private int nivel_crt;

    public Rezervor(int capacitate_max, int nivel_crt) {
        this.capacitate_max = capacitate_max;
        this.nivel_crt = nivel_crt;
    }
    public String toString() {
        return this.capacitate_max + " " + this.nivel_crt;
    }
    public void Unplere(int cant) {
        if(this.nivel_crt + cant >= this.capacitate_max)
            this.nivel_crt = this.capacitate_max;
        else this.nivel_crt += cant;
    }
    public void Golire(int cant) {
        if(this.nivel_crt - cant <= 0)
            this.nivel_crt = 0;
        else this.nivel_crt -= cant;
    }
}
