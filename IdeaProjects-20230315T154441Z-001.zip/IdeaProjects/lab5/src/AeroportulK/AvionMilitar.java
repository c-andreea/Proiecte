package AeroportulK;
import java.util.ArrayList;
public class AvionMilitar extends Aeronava{
    ArrayList<Echipament> listaEchipamente=new ArrayList<>();
    public final int numarEchipamente;

    ArrayList<Ruta> listaRuta=new ArrayList<>();
    public AvionMilitar(String nume, String numePilot, int nrPasageri, int nivelComvustibil, Stare stare, int numarEchipamente) {
        super(nume, numePilot, nrPasageri, nivelComvustibil, stare);
        this.numarEchipamente = numarEchipamente;
    }
    public void adaugarEchipamente(String nume, String codProdus, int cantitate){
        listaEchipamente.add(new Echipament(nume, codProdus, cantitate));

    }

    public void eliminarEchipamente(String nume, String codProdus, int cantitate){
        listaEchipamente.remove(codProdus);

    }
    public void zbor(String orasPlecare, String orasDest,int nrKm){
        Ruta rutta = new Ruta(orasPlecare, orasDest,nrKm);
        listaRuta.add(rutta);
        System.out.println(rutta);
    }
    public String getDesc(){
        return super.getDesc()+"Echipamente: "+listaEchipamente.toString();
    }
}
