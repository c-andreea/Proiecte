package SistemCoordonate;

import java.util.Scanner;

public class TestCoord {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Scanner scanner1= new Scanner(System.in);
        Scanner scanner2= new Scanner(System.in);
      int x=scanner.nextInt();
      int y=scanner1.nextInt();
      int z=scanner2.nextInt();



    }

}
