package R1;

public class TrenulNuExistaException extends Exception {
    public TrenulNuExistaException(String message) {
        super(message);
    }
}


