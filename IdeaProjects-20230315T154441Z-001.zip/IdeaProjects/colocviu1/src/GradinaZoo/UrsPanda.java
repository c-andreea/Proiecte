package GradinaZoo;

import java.sql.SQLOutput;

public class UrsPanda extends Animale{

    private int hraneste=0;
    public UrsPanda(String name, String culoare, int varsta,int nrOreDormite) {
        super(name, culoare, varsta);
        this.numarOreDormite=nrOreDormite;
    }

    private int numarOreDormite;

    @Override
    public void mananca(Mancare mancare) {
        System.out.println("\n Ursul a fost hranit"+mancare.toString());


    }

    public void somn(int ore){
        numarOreDormite+=ore;
        System.out.println("ursul a mai dormit "+numarOreDormite);

    }

    public String toPrint(){
        return super.toPrint() + "\nNumarOreDormite: " + numarOreDormite;
    }
}
