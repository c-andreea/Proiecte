package AeroportulK;

import java.util.Scanner;

public class TestFly {
    public static void main(String[] args) {
        System.out.println("Numar max aeronave: ");
    Scanner scanner = new Scanner(System.in);
     int nrMaxAeronave=scanner.nextInt();
     Aeroport aeroport=new Aeroport(nrMaxAeronave);

     Aeronava avion=new AvionPasageri("Boeing 747", "Mike Oxlong", 524,
             23000, Aeronava.Stare.ATERIZAT, 420);
     Aeronava militar=new AvionMilitar("C-5", "Mihai Paulica", 73,
             40000, Aeronava.Stare.ATERIZAT, 25);
     Aeronava elicopte=new Elicopter("Blackhawk UH60", "Donald Trump", 12,
             170, Aeronava.Stare.DECOLAT, "Stanga doboara dreapta omoara!");
        ((AvionMilitar)militar).adaugarEchipamente("AK-47", "xc304 ", 12);
        ((AvionMilitar)militar).adaugarEchipamente("AK-37", "xc704 ", 11);
aeroport.adaugar(avion);
aeroport.adaugar(militar);
aeroport.adaugar(elicopte);


aeroport.getDesc();

        ((AvionPasageri)avion).imbarcare(80);
        System.out.println("Numar pasageri: "+((AvionPasageri) avion).numarPasageri);
        ((AvionPasageri)avion).debarcare(60);
        System.out.println("Numar pasageri: "+((AvionPasageri) avion).numarPasageri);

        ((Elicopter)elicopte).afisareMesaj("A isit soarele din nori");

        ((AvionMilitar) militar).zbor("Bucuresti", "Cluj", 300);
        ((AvionMilitar) militar).zbor("Cluj", "Iasi", 308);
        ((AvionMilitar) militar).zbor("Iasi", "Istambul", 687);
        ((AvionMilitar) militar).zbor("Istambul", "Sofia", 504);
        ((AvionMilitar) militar).zbor("Sofia", "Viena", 818);
        ((AvionMilitar) militar).zbor("Viena", "Paris", 1031);
        ((AvionMilitar) militar).zbor("Paris", "Londra", 335);



    }



    }


