package Farmacia;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class TestData {
    Date dataExpirare = new Date(2022, 01, 01);
    Date dataExpirare1 = new Date(2022, 03, 01);
    Date dataFab1 = new Date(01,01,2021);
    List<String> ingrediente = Arrays.asList("ing1", "ing2", "ing3");
    @Test
    public void testDataExpirare() {

        Medicament medicament = new Medicament("Paracetamol", dataExpirare, 10,dataFab1, "001",ingrediente);
        Date dataCurenta = new Date(2022, 03, 01);
        Date dataExpirare2 = medicament.getDataExpirare();
        boolean expirat = dataCurenta.after(dataExpirare2);
        assertEquals(false, expirat);
    }

    @Test
    public void testCodUnic() {
        Medicament medicament = new Medicament("Paracetamol", dataExpirare, 10, dataFab1, "001",ingrediente);
        String codUnic = medicament.getCodUnic();
        assertEquals("002", codUnic);
    }
}