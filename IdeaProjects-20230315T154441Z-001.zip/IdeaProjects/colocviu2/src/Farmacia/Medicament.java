


package Farmacia;
import java.util.Date;
import java.util.*;
public class Medicament {
    private String nume;
    private Date dataExpirare;
    private double pret;
    private Date dataFabricatie;
    private String codUnic;
    private List<String> ingrediente;

    public Medicament(String nume, Date dataExpirare, double pret, Date dataFabricatie, String codUnic, List<String> ingrediente) {
        this.nume = nume;
        this.dataExpirare = dataExpirare;
        this.pret = pret;
        this.dataFabricatie = dataFabricatie;
        this.codUnic = codUnic;
        this.ingrediente = ingrediente;
    }

    public String getNume() {
        return nume;
    }

    public Date getDataExpirare() {
        return dataExpirare;
    }

    public double getPret() {
        return pret;
    }

    public Date getDataFabricatie() {
        return dataFabricatie;
    }

    public String getCodUnic() {
        return codUnic;
    }

    public List<String> getIngrediente() {
        return ingrediente;
    }
}
