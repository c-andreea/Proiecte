package Masini;

public class Autovehicul {

    private Sofer sofer;
    private Rezervor rezervor;
    private String marca;
    private String culoare;
    private int treapta_crt, viteza_crt;
    private final int vitezaMaxima = 280;
    private final int numarDeTrepte = 6;

    public void setSofer(Sofer sofer) {
        this.sofer = sofer;
    }

    public Sofer getSofer() {
        return sofer;
    }

    public Rezervor getRezervor() {
        return rezervor;
    }

    public void setRezervor(Rezervor rezervor) {
        this.rezervor = rezervor;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public Autovehicul() {
        this.marca = "Dacia";
        this.culoare = "alba";

    }

    public Autovehicul(String marca, String culoare, int treapta_crt, int viteza_crt) {
        this.marca = marca;
        this.culoare = culoare;
        this.treapta_crt = treapta_crt;
        this.viteza_crt = viteza_crt;

    }

    public String toString() {
        return this.marca + " " + this.culoare + " " + this.viteza_crt + " " + this.treapta_crt + " Soferul este: " + this.sofer + " Iar capacitatea rezervorului: " + this.rezervor;
    }

    public String getMarca() {
        return this.marca;
    }
    public void Accelerare(int crestere) {
        if(this.viteza_crt + crestere <= vitezaMaxima)
            this.viteza_crt += crestere;
        else this.viteza_crt = this.vitezaMaxima;
    }
    private String crestere;
    public void Accelerare(String crestere) {
        if(this.viteza_crt + Integer.valueOf(crestere) <= vitezaMaxima)
            this.viteza_crt += Integer.valueOf(crestere);
        else this.viteza_crt = this.vitezaMaxima;
    }
    public void Decelerare(int scadere) {
        if(this.viteza_crt - scadere >= 0)
            this.viteza_crt -= scadere;
    }

}
