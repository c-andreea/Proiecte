package pob6_1;

public class MyException extends Exception {
}
