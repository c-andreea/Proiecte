package tema3_6;

public interface Icomand {
    void execute();
    void undo();
}
