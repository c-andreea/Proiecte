package CofetariaPaul;

public class Tort extends Prajituri{
    public Tort(String name, int pret, int timpCoacere,String tipCioccolata) {
        super(name, pret, timpCoacere);
        this.tipCioccolata = tipCioccolata;

    }

    public String getTipCioccolata() {
        return tipCioccolata;
    }

    public void setTipCioccolata(String tipCioccolata) {
        this.tipCioccolata = tipCioccolata;
    }

    public String tipCioccolata;


    @Override
    public void coacere(int timp,Cofetar cofetar,Prajituri pra) {
        if(timp==timpCoacere)
        {
            System.out.println("\ngata prajitura");
            cofetar.gataPraj(pra);

        }
       else if(timp<=timpCoacere)
        {
            System.out.println("\nnu este gata");
        }
       else
        {
            System.out.println("\ns-a ars prajitura");
            cofetar.gataPraj(pra);

        }

    }

    public String toPrint() {
        return super.toPrint() + "\nTip cioccolata: " + tipCioccolata;
    }

}
