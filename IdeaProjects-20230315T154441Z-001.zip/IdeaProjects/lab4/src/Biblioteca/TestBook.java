package Biblioteca;

public class TestBook {
    public static void main(String[] args)
    {
        Carte prima= new Carte("123","Ion",'A',1960,"litera");
        Autor autor1=new Autor("Preda","marin",45);
        prima.setAutor(autor1);
        System.out.println(prima.toString());
    }
}
