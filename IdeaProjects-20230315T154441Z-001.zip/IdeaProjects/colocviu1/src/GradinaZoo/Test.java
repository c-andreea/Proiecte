package GradinaZoo;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
       String numeGradina;
       numeGradina = scanner.nextLine();

        System.out.println("Numele gradinii: " + numeGradina);
GradinaZoologica gradina=new GradinaZoologica();

UrsPanda panda=new UrsPanda("Martinel","alb cu negru",10,20);
Pinguin pinguin=new Pinguin("Rico","alb cu negru",10,3000);
Delfin delfin=new Delfin("Mimi","albastru",15,500);

gradina.agregar(panda);
gradina.agregar(pinguin);
gradina.agregar(delfin);

Ingrijitor ingrijitor=new Ingrijitor("ion",20);
ingrijitor.addAnimale(panda);
ingrijitor.addAnimale(pinguin);

Mancare mancare1=new Mancare("Bambus",10,"12:30");
Mancare mancare2=new Mancare("Nustiu",13,"10:40");
        ingrijitor.toDesc();
        gradina.toPrint();
panda.mananca(mancare1);
pinguin.mananca(mancare2);

panda.somn(20);
pinguin.plimbare(30);
delfin.inot(70);







    }
}
