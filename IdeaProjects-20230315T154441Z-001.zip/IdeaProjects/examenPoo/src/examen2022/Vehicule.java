package examen2022;

public abstract class Vehicule {
    private String nume;
    private String culoare;
    private int anul;



    public Vehicule(String nume, String culoare, int anul) {
        this.nume = nume;
        this.culoare = culoare;
        this.anul = anul;
    }

    public String toString(){
        return "Nume: " + nume + " Culoare: " + culoare + " Anul: " + anul;
    }
public int getAn(){
        return this.anul;
}

}
