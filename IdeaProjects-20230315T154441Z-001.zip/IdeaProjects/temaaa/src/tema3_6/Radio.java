package tema3_6;

public class Radio extends Functii implements IRadio {
    public int volum;
    public Radio( String name,int voulm) {
        super(name);
        this.volum = voulm;
    }

    @Override
    public void up() {
        if(volum <= 30)
            volum ++;
        System.out.println("Volumul este la: " + volum);

    }

    @Override
    public void down() {
        if(volum >= 0)
            volum --;
        System.out.println("Volumul este la: " + volum);

    }

    @Override
    public void connect() {
        System.out.println("Un dispozitiv a fost conectat la masina");
    }

    @Override
    public void disconnect() {
        System.out.println("Un dispozitiv a fost deconectat la masina");
    }
}
