package exemplu1;

import java.util.Comparator;

class NumeAeronaveComparator implements Comparator<Aeronave> {
    @Override
    public int compare(Aeronave a1, Aeronave a2) {
        return a1.getNume().compareToIgnoreCase(a2.getNume());
    }
}
