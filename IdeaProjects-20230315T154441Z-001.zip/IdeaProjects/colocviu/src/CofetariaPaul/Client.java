package CofetariaPaul;

public class Client {

    public Client(String id) {
        this.Id = id;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String Id;
    public int pretTotal=0;

    public void cumpara1(Prajituri pra)
    {
        pretTotal+=pra.pret;
    }

    public void toPtint(){
        System.out.println("\nId: "+Id+"\npret:"+pretTotal);
    }
}
