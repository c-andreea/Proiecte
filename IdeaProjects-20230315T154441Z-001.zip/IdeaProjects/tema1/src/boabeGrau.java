import java.math.BigInteger;

public class boabeGrau
{

    public static void main (String[] args)
    {
        sePrinteazaBoabele(64);
    }

    public static void sePrinteazaBoabele( int numar )
    {
        BigInteger num = new BigInteger("2");
        for (int i = 1; i <= numar; i++)
        {
            System.out.println("patratul " + i + ":  " + num + " boabe.");
            num = num.multiply(new BigInteger("2"));
        }
    }

}