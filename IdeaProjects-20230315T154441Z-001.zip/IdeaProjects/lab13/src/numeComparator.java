import java.util.Comparator;

public class numeComparator implements Comparator<Tren>{

	@Override
	public int compare(Tren a, Tren b) {
		 if(a.getOraPlecarii()>b.getOraPlecarii())
			 return 1;
		 else  if(a.getOraPlecarii()<b.getOraPlecarii())
			 return -1;
		 else if(a.getMinutulPlecarii()>b.getMinutulPlecarii())
			 return 1;
		 return -1;
	}
}