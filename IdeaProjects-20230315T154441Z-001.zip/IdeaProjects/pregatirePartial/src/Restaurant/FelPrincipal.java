package Restaurant;

public class FelPrincipal extends Preparat{
    public FelPrincipal(String id, String name, String specific,int calorii, String tipCarne, Glutten gluten ) {
        super(id, name, specific);
        this.calorii=calorii;
        this.tipCarne=tipCarne;
        this.gluten=gluten;



    }


    public int calorii;



    public String tipCarne;

    public int getCalorii() {
        return calorii;
    }

    public String getTipCarne() {
        return tipCarne;
    }
    public void setCalorii(int calorii) {
        this.calorii = calorii;
    }

    public void setTipCarne(String tipCarne) {
        this.tipCarne = tipCarne;
    }
    enum Glutten{
        da,
      nu;

    }
    Glutten gluten;
    public void agluten(){this.gluten=Glutten.da;}
    public void nu_agluten(){this.gluten=Glutten.nu;}

    public String toPrint(){
        return super.toPrint() + "\nCalorii: " + calorii + "\nTip: " + tipCarne+"\nGluten: "+gluten;
    }


}
