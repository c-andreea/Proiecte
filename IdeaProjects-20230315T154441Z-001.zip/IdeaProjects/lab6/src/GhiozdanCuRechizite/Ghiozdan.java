package GhiozdanCuRechizite;

public class Ghiozdan {
    public Rechizite[] lista=new Rechizite[10];
    public int nrRechizita=0;

    public void add(Rechizite rechizite)
    {
        lista[nrRechizita++]=rechizite;
    }
    public void afisare()
    {
        System.out.println("Rechizitele din ghiozdan sunt:");
for(int i=0;i<nrRechizita;i++)
    System.out.println(lista[i].getNume());
    }

    public void afisareCaiet()
    {
        System.out.println("Caietele sunt:");
        for(int i=0;i<nrRechizita;i++){
            if(lista[i] instanceof Caiet){
            System.out.println(lista[i].getNume());}}
    }

}
