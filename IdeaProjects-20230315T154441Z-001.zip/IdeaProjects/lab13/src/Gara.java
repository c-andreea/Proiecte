import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Gara {
	public List<Tren> t;

	public Gara() {
		this.t=new ArrayList<Tren>();
	}

	public List<Tren> getT() {
		return t;
	}

	public void setT(List<Tren> t) {
		this.t = t;
	}
	
	public void addT(Tren p) {
		t.add(p);
	}
	
	public void deleteT(Tren p) {
		t.remove(p);
	}
	
	public void afisareLista() {
		for(Tren trenulet : t) {
			System.out.println("Cod: " + trenulet.getCod() + " Destinatie: " + trenulet.getDestinatie() + " Ora: " + trenulet.getOraPlecarii() + ":" + trenulet.getMinutulPlecarii());
		}
	}
	
	public String cautare(String cod) {
		for (Tren trenulet : t) {
			if(trenulet.getCod().equals(cod)) {
				System.out.println("Cod: " + trenulet.getCod() + " Destinatie: " + trenulet.getDestinatie() + " Ora: " + trenulet.getOraPlecarii() + ":" + trenulet.getMinutulPlecarii());
				return "Cod: " + trenulet.getCod() + " Destinatie: " + trenulet.getDestinatie() + " Ora: " + trenulet.getOraPlecarii() + ":" + trenulet.getMinutulPlecarii();
		}
	}
		return "Nu s-a gasit";
	}
	
	public void sortareT() {
		Collections.sort(getT(), new numeComparator());
	}
}
