package CofetariaPaul;

import java.util.ArrayList;

public class Ingredient {

    public String getNume() {
        return nume;
    }

    public int getCantitate() {
        return cantitate;
    }

    private String nume;

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }

    public Ingredient(String nume,int cantitate) {
        this.nume = nume;
        this.cantitate = cantitate;

    }
    private int cantitate;

    public String toPrint() {
        return "\nNume: "+nume + "\nCantitate: " + cantitate;

    }
}
