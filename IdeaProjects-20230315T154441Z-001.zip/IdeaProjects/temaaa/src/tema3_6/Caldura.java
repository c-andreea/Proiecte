package tema3_6;

public class Caldura extends Functii implements ISchimba{

    public int treapta;

    public Caldura(String name,int treapta) {
        super(name);
        this.treapta = treapta;
    }

    @Override
    public void Tup() {
        if(treapta <= 4)
        treapta ++;
        System.out.println("Caldura este pe modul : " +treapta);

    }

    @Override
    public void Tdown() {
        if(treapta >= 0)
            treapta --;
        System.out.println("Caldura este pe modul : " +treapta);
    }
}
