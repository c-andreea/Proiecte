package exemplu1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

public static void main(String[] args) {
        CentrulSpatialMarte centrulSpatialMarte = new CentrulSpatialMarte();


        Aeronave aeronava1 = new RacheteApolo("Apollo 1", 20000, "Alb", 1970, "Luna");
    Aeronave aeronava3 = new Aeronave.AvioaneBoeing("Boeing 747", 15000, "Argintiu", 1968, 200);
        Aeronave aeronava2 = new RacheteApolo("Apollo 2", 25000, "Albastru", 1972, "Marte");

        Aeronave aeronava4 = new Aeronave.AvioaneBoeing("Boeing 787", 18000, "Alb", 2010, 250);

        centrulSpatialMarte.adaugaAeronava(aeronava1);
        centrulSpatialMarte.adaugaAeronava(aeronava2);
        centrulSpatialMarte.adaugaAeronava(aeronava3);
        centrulSpatialMarte.adaugaAeronava(aeronava4);

        Angajati angajat1 = new Om("John", 35);
        Angajati angajat2 = new Om("Jane", 30);
        Angajati angajat3 = new Robot("Robot1", 5);
        Angajati angajat4 = new Robot("Robot2", 7);

        centrulSpatialMarte.adaugaAngajat(angajat1);
        centrulSpatialMarte.adaugaAngajat(angajat2);
        centrulSpatialMarte.adaugaAngajat(angajat3);
        centrulSpatialMarte.adaugaAngajat(angajat4);

        Piloti pilot1 = new Piloti("Alex", "Smith", 40, "Capitan");
        Piloti pilot2 = new Piloti("Mike", "Johnson", 45, "Comandant");

        centrulSpatialMarte.adaugaPilot(pilot1);
        centrulSpatialMarte.adaugaPilot(pilot2);

        // Sortarea listei de aeronave in ordine alfabetica
        List<Aeronave> aeronave = new ArrayList<>(centrulSpatialMarte.getAeronave());
        Collections.sort(aeronave, new NumeAeronaveComparator());
        System.out.println("Aeronave sortate alfabetic: ");
        for (Aeronave aeronava : aeronave) {
        System.out.println(aeronava.getNume()+" ");}

    System.out.println("\nAngajatii din centru: ");
    for (Angajati angajat : centrulSpatialMarte.getAngajati()) {
        System.out.println(angajat.getNume() + " - " + angajat.getTip());
    }

// Afisarea pilotiilor din centru
    System.out.println("\nPilotii din centru: ");
    for (Piloti pilot : centrulSpatialMarte.getPiloti()) {
        System.out.println(pilot.getNume() + " " + pilot.getPrenume() + " - " + pilot.getGrad());
}
    Angajati angajatUman = new Om("John", 35);
    Angajati angajatRobot = new Robot("Robot1", 5);

    centrulSpatialMarte.adaugaAngajat(angajatUman);
    centrulSpatialMarte.adaugaAngajat(angajatRobot);
    System.out.println("Activitate angajat uman:");
    angajatUman.mananca();
    angajatUman.doarme();
    angajatUman.facePauza();
    angajatUman.lucreaza();

    System.out.println("Activitate angajat robot:");
    angajatRobot.lucreaza();



    LocalDateTime dataPlecare1 = LocalDateTime.of(2022, 10, 15, 8, 30);
    LocalDateTime dataPlecare2 = LocalDateTime.of(2022, 12, 20, 12, 15);
    LocalDateTime dataPlecare3 = LocalDateTime.of(2023, 1, 10, 14, 45);

    centrulSpatialMarte.inregistreazaPlecareRachete((RacheteApolo) aeronava1, dataPlecare1);
    centrulSpatialMarte.inregistreazaPlecareRachete((RacheteApolo) aeronava2, dataPlecare2);
    //centrulSpatialMarte.inregistreazaPlecareRachete((RacheteApolo) aeronava3, dataPlecare3);

    LocalDateTime dataCautare = LocalDateTime.of(2022, 12, 1, 0, 0);
    try {
        List<RacheteApolo> rachetePlecate = centrulSpatialMarte.getRachetePlecateDupaData(dataCautare);
        System.out.println("Rachetele care au plecat dupa data " + dataCautare + " sunt:");
        for (RacheteApolo racheta : rachetePlecate) {
            System.out.println(racheta.getNume());
        }
    } catch (ExceptionRachete ex) {
        System.out.println(ex.getMessage());
    }

}}