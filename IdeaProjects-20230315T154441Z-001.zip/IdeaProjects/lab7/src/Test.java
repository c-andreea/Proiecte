public class Test {
public static void main(String[] args) throws CloneNotSupportedException {
    Masina masinaComuna= new Masina("BMW", "alba");
    Student student1=new Student("Bob",masinaComuna);
    Student student2=(Student) student1.clone();

    student2.nume="Alex";
    System.out.println("Culoarea initiala: "+student1.masina.getCuloare()+" "+student1.nume+"\n");
    System.out.println("Culoarea initiala: "+student2.masina.getCuloare()+" "+student2.nume+"\n");

    student2.masina.setCuloare("rosu");
    System.out.println("Culoarea initiala: "+student1.masina.getCuloare()+" "+student1.nume+"\n");
    System.out.println("Culoarea initiala: "+student2.masina.getCuloare()+" "+student2.nume+"\n");

}

}
