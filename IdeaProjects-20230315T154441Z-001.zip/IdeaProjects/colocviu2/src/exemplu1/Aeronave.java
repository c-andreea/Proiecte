package exemplu1;

class Aeronave {
    private String nume;
    private int numarMaximKm;
    private String culoare;
    private int anFabricatie;

    public Aeronave(String nume, int numarMaximKm, String culoare, int anFabricatie) {
        this.nume = nume;
        this.numarMaximKm = numarMaximKm;
        this.culoare = culoare;
        this.anFabricatie = anFabricatie;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getNumarMaximKm() {
        return numarMaximKm;
    }

    public void setNumarMaximKm(int numarMaximKm) {
        this.numarMaximKm = numarMaximKm;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public int getAnFabricatie() {
        return anFabricatie;
    }

    public void setAnFabricatie(int anFabricatie) {
        this.anFabricatie = anFabricatie;
    }

    static class AvioaneBoeing extends Aeronave {
        private int numarPasageri;

        public AvioaneBoeing(String nume, int numarMaximKm, String culoare, int anFabricatie, int numarPasageri) {
            super(nume, numarMaximKm, culoare, anFabricatie);
            this.numarPasageri = numarPasageri;
        }

        public int getNumarPasageri() {
            return numarPasageri;
        }

        public void setNumarPasageri(int numarPasageri) {
            this.numarPasageri = numarPasageri;
        }
    }
}
