package utilities;

public interface GameTimer {
    long GetCurrentUpdateCount();
}
