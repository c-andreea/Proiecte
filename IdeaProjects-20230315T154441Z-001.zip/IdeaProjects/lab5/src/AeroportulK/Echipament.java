package AeroportulK;

public class Echipament {
    private String nume;
    private String codProdus;
    private int cantitate;

    public Echipament(String nume, String codProdus, int cantitate)
    {
        this.nume = nume;
        this.codProdus = codProdus;
        this.cantitate = cantitate;

    }
    public void adauga(int marfa){
        this.cantitate = this.cantitate + marfa;

    }
    public void descarca(int marfa){
        this.cantitate = this.cantitate - marfa;

    }
      public String toString(){
        return "cod produs"+codProdus + "Nume " + nume + "Cantitate " + cantitate;

      }
}
