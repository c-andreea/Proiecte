package R1;

import org.junit.Test;

import java.time.LocalTime;
import java.util.List;

import static org.junit.Assert.*;
//import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestTren {
    @Test
    public void testAjungeLaDestinatie() {
        Gara gara = new Gara("Gara centrala");
        Tren tren1 = new Tren("Manchester", LocalTime.of(9, 0), "W1M");
        Tren tren2 = new Tren("Liverpool", LocalTime.of(15, 45), "W5L");
        gara.adaugaTren(tren1);
        gara.adaugaTren(tren2);
        List<Tren> trenuri = gara.getTrenuri();

        String codTren = "W5L";
        String destinatie = "Liverpool";
        boolean ajungeLaDestinatie = false;
        for (Tren tren : trenuri) {
            if (tren.getCodUnic().equals(codTren) && tren.getDestinatie().equals(destinatie)) {
                ajungeLaDestinatie = true;
                break;
            }
        }
        assertTrue(ajungeLaDestinatie);
    }
}
