package CofetariaPaul;

import java.util.ArrayList;

public abstract class Prajituri {

    public String getName() {
        return name;
    }

    public int getPret() {
        return pret;
    }

    public int getTimpCoacere() {
        return timpCoacere;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPret(int pret) {
        this.pret = pret;
    }

    public void setTimpCoacere(int timpCoacere) {
        this.timpCoacere = timpCoacere;
    }
private int nrIngrediente;
    protected String name;
    public int pret;
    protected int timpCoacere;
    ArrayList<Ingredient> listaIngredientes = new ArrayList();

    public Prajituri(String name, int pret, int timpCoacere)
    {
        this.name = name;
        this.pret = pret;
        this.timpCoacere = timpCoacere;

    }

    public void addIngredient(Ingredient ingredient)
    {
      listaIngredientes.add(ingredient);
      nrIngrediente++;

    }


    public abstract void coacere(int timp,Cofetar cofetar, Prajituri pra);

    public String toPrint(){


        for(Ingredient ingredient : listaIngredientes) {
            return "\nIngrediente: " + ingredient.toPrint()+"\nNume prajitura: "+name + "\nPret: " + pret + "\nTimp coacere: " + timpCoacere;
        }

        return null;
    }

}
