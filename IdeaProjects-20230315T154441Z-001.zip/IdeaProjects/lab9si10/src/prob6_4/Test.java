package prob6_4;
public class Test {
    public static void main(String[] args) {
        try {
            throw new Exception("An exception occurred");
        } catch (Exception e) {
            System.out.println("Caught exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed");
        }
    }
}