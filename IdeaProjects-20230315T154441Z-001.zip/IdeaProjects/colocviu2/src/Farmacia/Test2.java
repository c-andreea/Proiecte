package Farmacia;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.*;

public class Test2 extends JFrame {
    private JTextField codField;
    private JButton cautaButton;
    private Farmacie farmacie;
    private JPanel afisarePanel;
    private JLabel codLabel;
    private JLabel numeLabel;
    private JLabel pretLabel;
    private JLabel ingredienteLabel;

    private void createAndShowGUI() {
        Date dataFab1 = new Date(01,01,2021);
        Date dataFab2 = new Date(01,01,2021);
        Date dataExpirare1 = new Date(2022, 01, 01);
        Date dataExpirare2 = new Date(2022, 02, 01);

        List<String> ingrediente = Arrays.asList("ing1", "ing2", "ing3");
     farmacie = new Farmacie("Catena", "Str. Stefan cel Mare nr. 15");
        Medicament paracetamol = new Medicament("Paracetamol", dataExpirare1, 5.50, dataFab1, "A1B2C3",ingrediente);
        Medicament ibuprofen = new Medicament("Ibuprofen", dataExpirare2, 7.50, dataFab2, "D4E5F6",ingrediente);
        farmacie.adaugaMedicament(paracetamol);
        farmacie.adaugaMedicament(ibuprofen);
        setTitle("Cautare medicament");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        codField = new JTextField(10);
        add(codField);

        cautaButton = new JButton("Cauta");
        cautaButton.addActionListener(new CautaListener());
        add(cautaButton);

        afisarePanel = new JPanel();
        afisarePanel.setLayout(new BoxLayout(afisarePanel, BoxLayout.Y_AXIS));
        codLabel = new JLabel("Cod: ");
        numeLabel = new JLabel("Nume: ");
        pretLabel = new JLabel("Pret: ");
        ingredienteLabel = new JLabel("Ingrediente: ");
        afisarePanel.add(codLabel);
        afisarePanel.add(numeLabel);
        afisarePanel.add(pretLabel);
        afisarePanel.add(ingredienteLabel);

        add(afisarePanel);

        setVisible(true);
    }

    private class CautaListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String cod = codField.getText();
            try {
                Medicament medicament = farmacie.cautaMedicament(cod);
                codLabel.setText("Cod: " + medicament.getCodUnic());
                numeLabel.setText("Nume: " + medicament.getNume());
                pretLabel.setText("Pret: " + medicament.getPret());
                ingredienteLabel.setText("Ingrediente: "+medicament.getIngrediente());
            } catch (MedicamentInexistentException ex) {
                JOptionPane.showMessageDialog(Test2.this, ex.getMessage(), "Eroare", JOptionPane.ERROR_MESSAGE);
                System.out.println(ex.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Test2 test2 = new Test2();
                test2.createAndShowGUI();
            }
        });
    }}

