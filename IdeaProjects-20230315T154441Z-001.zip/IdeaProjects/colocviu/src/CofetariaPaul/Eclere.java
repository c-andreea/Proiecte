package CofetariaPaul;

public class Eclere extends Prajituri{
    public Eclere(String name, int pret, int timpCoacere,String tipCreme) {
        super(name, pret, timpCoacere);
        this.tipCreme = tipCreme;

    }

    public String getTipCreme() {
        return tipCreme;
    }

    public void setTipCreme(String tipCreme) {
        this.tipCreme = tipCreme;
    }

    private String tipCreme;

    @Override
    public void coacere(int timp,Cofetar cofetar,Prajituri pra) {
        if(timp==timpCoacere)
        {
            System.out.println("\ngata prajitura");
            cofetar.gataPraj(pra);

        }
       else if(timp<=timpCoacere)
        {
            System.out.println("\nnu este gata");
        }
        else
        {
            System.out.println("\ns-a ars prajitura");
            cofetar.gataPraj(pra);

        }

    }

    public String toPrint(){
        return super.toPrint() + "\nTip crema: " + tipCreme;
    }

}
