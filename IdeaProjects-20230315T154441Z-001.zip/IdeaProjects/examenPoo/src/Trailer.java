import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Trailer {
	private int masaMaxima;
	private int nrMaxAutoturisme;
	private int nrMaxMicrobuze;
	private ArrayList<Autoturism> autoturisme;
	private ArrayList<Microbuz> microbuze;
	
	public Trailer() {
		Scanner s = new Scanner(System.in);
		System.out.println("Masa maxima trailer: ");
		masaMaxima=s.nextInt();
		System.out.println("Numar max. autoturisme: ");
		nrMaxAutoturisme=s.nextInt();
		System.out.println("Numar max. microbuze: ");
		nrMaxMicrobuze=s.nextInt();
		autoturisme = new ArrayList<Autoturism>();
		microbuze = new ArrayList<Microbuz>();
	}
	
	public void adaugaAutovehicul (Autovehicul x) throws Exception{
		if (x instanceof Autoturism)
		{
			if (x.getMasa()+masaIncarcata()<=masaMaxima && autoturisme.size()<nrMaxAutoturisme)
				autoturisme.add((Autoturism)x);
			else
				throw new Exception ("Nu se poate adauga autoturismul!!!");
		}
		else
		{
			if (x.getMasa()+masaIncarcata()<=masaMaxima && microbuze.size()<nrMaxMicrobuze)
				microbuze.add((Microbuz)x);
			else
				throw new Exception ("Nu se poate adauga microbuzul!!!");			
		}
	}
	
	private int masaIncarcata() {	
		int masa=0;
		for (Autoturism x: autoturisme)
			masa += x.getMasa();
		for (Microbuz x: microbuze)
			masa += x.getMasa();
		return masa;
	}
	
	public void scoate(Autovehicul x)
	{
		if (x instanceof Autoturism)
			autoturisme.remove(x);
		else
			microbuze.remove(x);
	}
	
	public int nrLocuriLibere() {
		return nrMaxAutoturisme+nrMaxMicrobuze-autoturisme.size() - microbuze.size();
	}
	
	public int nrAutoturismeSport() {
		int contor=0;
		for (Autoturism x: autoturisme)
			if (x.isSport())
				contor++;
		return contor;
	}
	
	public void detalii() {
		ArrayList<Autovehicul> a = new ArrayList<Autovehicul>();
		a.addAll(autoturisme);
		a.addAll(microbuze);
		Collections.sort(a);
		for (Autovehicul x: a)
			System.out.println(x);
	}
	
}
