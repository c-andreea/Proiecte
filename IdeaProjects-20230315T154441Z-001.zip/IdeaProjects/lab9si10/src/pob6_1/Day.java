package pob6_1;

public class Day {
    private String name;
    private boolean isWorking;

    public Day(String name, boolean isWorking) {
        this.name = name;
        this.isWorking = isWorking;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setWorking() {
        this.isWorking = true;
    }

    public void setNotWorking() {
        this.isWorking = false;
    }

    public boolean isWorking() {
        return isWorking;
    }
}

