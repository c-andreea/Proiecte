package Masini;

public class Sofer {
    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    private String nume;

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    private String prenume;

    public int getVarsta() {
        return varsta;
    }

    private int varsta;

    public int getNumarPermisDeConducere() {
        return numarPermisDeConducere;
    }

    private int numarPermisDeConducere;
    public Sofer()
    {
        this.nume="nume";
        this.prenume="prenume";

    }
    public Sofer(String nume, String prenume,int varsta, int numarPermisDeConducere){
        this.nume=nume;
        this.prenume=prenume;
        this.varsta=varsta;
        this.numarPermisDeConducere=numarPermisDeConducere;
    }
    public String toString(){
        return "nume "+ this.nume+" prenume "+ this.prenume+ " varsta "+ this.varsta + " " + this.numarPermisDeConducere;
    }

}
