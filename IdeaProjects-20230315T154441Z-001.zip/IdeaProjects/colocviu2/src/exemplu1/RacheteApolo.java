package exemplu1;

import java.time.LocalDateTime;

class RacheteApolo extends Aeronave {
    private String destinatie;
    private LocalDateTime dataPlecare;

    public RacheteApolo(String nume, int kmMaxim, String culoare, int anFabricatie, String destinatie) {
        super(nume, kmMaxim, culoare, anFabricatie);
        this.destinatie = destinatie;
    }

    public String getDestinatie() {
        return destinatie;
    }

    public LocalDateTime getDataPlecare() {
        return dataPlecare;
    }

    public void setDataPlecare(LocalDateTime dataPlecare) {
        this.dataPlecare = dataPlecare;
    }
}
