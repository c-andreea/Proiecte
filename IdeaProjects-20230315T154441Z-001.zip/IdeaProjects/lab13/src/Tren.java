
public class Tren {
	private String destinatie;
	private int oraPlecarii;
	private int minutulPlecarii;
	private String cod;

	public Tren(String nume, int ora, int min, String cod) {
		this.destinatie=nume;
		this.oraPlecarii=ora;
		this.cod=cod;
		this.minutulPlecarii=min;
	}

	public String getDestinatie() {
		return destinatie;
	}

	public int getMinutulPlecarii() {
		return minutulPlecarii;
	}

	public void setMinutulPlecarii(int minutulPlecarii) {
		this.minutulPlecarii = minutulPlecarii;
	}

	public void setDestinatie(String destinatie) {
		this.destinatie = destinatie;
	}

	public int getOraPlecarii() {
		return oraPlecarii;
	}

	public void setOraPlecarii(int oraPlecarii) {
		this.oraPlecarii = oraPlecarii;
	}

	public String getCod() {
		return cod;
	}

	public void setCod(String cod) {
		this.cod = cod;
	}
}
