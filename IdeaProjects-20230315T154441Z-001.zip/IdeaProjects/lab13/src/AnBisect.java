
public class AnBisect
{
    public boolean isAnBisect(int an) {
        if (an % 4 == 0) {
            if (an % 100 == 0) {
                if (an % 400 == 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
}