package loterie;
import java.lang.Math;
import java.util.Random;

public class Loto {

    public int[] generareNumere(){
        Random random=new Random();
        int[] numereGenerate=new int[6];
        for(int i=0;i<6;i++)
        {
            numereGenerate[i]=random.nextInt(50);

        }
        return numereGenerate;
    }

}
