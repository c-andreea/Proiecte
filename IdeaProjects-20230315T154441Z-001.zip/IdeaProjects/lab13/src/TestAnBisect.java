import static org.junit.Assert.*;
//import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.*;

public class TestAnBisect {
    AnBisect anBisect = new AnBisect();

    @Test
    public void testIsAnBisect() {
        assertTrue(anBisect.isAnBisect(4));
    }
    @Test
    public void testIsAnBisect2() {

        assertTrue(!anBisect.isAnBisect(99));

    }
}