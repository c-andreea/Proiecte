package tema3_6;




public class Masina implements IStart {

    public String marca;
    public String placuta;


    public Masina(String marca, String placuta) {
        this.marca = marca;
        this.placuta = placuta;
    }


    @Override
    public void start() {
        System.out.println("Masina "+ marca+" cu numarul: "+placuta+" a pornit");

    }

    @Override
    public void stop( ) {
        System.out.println("Masina "+ marca+" cu numarul: "+placuta+" a fost oprita");

    }
}
