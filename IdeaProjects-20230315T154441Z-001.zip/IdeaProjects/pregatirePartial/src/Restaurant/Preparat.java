package Restaurant;

public abstract  class Preparat {
    public String specific;
    public String name;
    public String id;
    private String numarDeOrdine;

    public String getSpecific() {
        return specific;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }
    public Preparat(String id, String name, String specific) {
        this.id = id;
        this.name = name;
        this.specific = specific;
    }
    public void setSpecific(String specific) {
        this.specific = specific;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }
public void getnemar(String id,String name) {
        String str=name.length() < 2 ? name : name.substring(0, 2);

        numarDeOrdine="0";
}


    public String toPrint() {
        return "Id: "+id + "\nNume: " + name + "\nSpecific: " + specific+"\nNumar: " + id.concat(name.substring(0, 2))+"\n";

    }
}
