package pob6_1;



public class CalendarWork {
        private Day[] days;

        public CalendarWork() {
                days = new Day[7];
                days[0] = new Day("Monday", true);
                days[1] = new Day("Tuesday", true);
                days[2] = new Day("Wednesday", true);
                days[3] = new Day("Thursday", true);
                days[4] = new Day("Friday", true);
                days[5] = new Day("Saturday", false);
                days[6] = new Day("Sunday", false);
        }

        public void setDay(int index, Day day) {
                days[index] = day;
        }

        public Day getDay(int index) {
                return days[index];
        }
}
