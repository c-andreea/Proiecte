package Arhiva;

public class Angajat {
}
