import java.util.Map;
import java.util.HashMap;

public class DictionarRomanEnglez {
    private Map<String, String> dictionar;

    public DictionarRomanEnglez() {

        dictionar = new HashMap<String, String>();


        dictionar.put("casa", "house");
        dictionar.put("pisica", "cat");
        dictionar.put("copil", "child");
        dictionar.put("fruct", "fruit");
        dictionar.put("copac", "tree");
        dictionar.put("apa", "water");
        dictionar.put("paine", "bread");
        dictionar.put("masina", "car");
        dictionar.put("carte", "book");
        dictionar.put("iarba", "grass");
    }


    public void afis() {
        System.out.println("Numarul de cuvinte din dictionar este : " + dictionar.size());
    }


    public void afisCuvintele() {
        for (Map.Entry<String, String> entry : dictionar.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }


    public void afisCuvinteleRo() {
        for (String key : dictionar.keySet()) {
            System.out.println(key);
        }
    }


    public void afisCuvinteleEng() {
        for (String value : dictionar.values()) {
            System.out.println(value);
        }
    }

    public void schimbaTraducerea(String romanianWord, String newTranslation) {
        if (dictionar.containsKey(romanianWord)) {
            dictionar.put(romanianWord, newTranslation);
            System.out.println(" Noua traducere a cuvantului " + romanianWord + " : " + newTranslation);
        } else {
            System.out.println("Cuvantul nu a fost gasit.");
        }
    }

    public static void main(String[] args) {
        DictionarRomanEnglez dict = new DictionarRomanEnglez();

        dict.afis();
        

        dict.afisCuvintele();

        System.out.println("Cuvintele in romana sunt:");
        dict.afisCuvinteleRo();

        System.out.println("cuvintele in engleza sunt:");
        dict.afisCuvinteleEng();

        dict.schimbaTraducerea("casa", "home");

    }
}




