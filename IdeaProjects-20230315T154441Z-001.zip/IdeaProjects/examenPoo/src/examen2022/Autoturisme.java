package examen2022;

public class Autoturisme extends Vehicule {
    private String numarInmatriculare;
    private int capacitateCilindrica;

    public Autoturisme(String marca, String culoare, int an, String numarInmatriculare, int capacitateCilindrica){
        super(marca,culoare,an);
        this.numarInmatriculare = numarInmatriculare;
        this.capacitateCilindrica = capacitateCilindrica;
    }

    public String toString(){
        return super.toString() + " Numar Inmatriculare: " + numarInmatriculare + " Capacitate Cilindrica: " + capacitateCilindrica;
    }
}
