package examen2022;

public class Main {
    public static void main(String[] args) {
        Parcare par = new Parcare();
        Autoturisme a1 = new Autoturisme("BMW","Rosu",2010,"B 12 ABC",2000);
        Autoturisme a2 = new Autoturisme("Audi","Albastru",2015,"B 12 ABC",2000);
        Biciclete b1 = new Biciclete("Bicicleta1","Rosu",2010,"B 12 ABC");
        Biciclete b2 = new Biciclete("Bicicleta2","Albastru",2015,"B 12 ABC");

        try {
            par.parcheaza(a1, 1);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        try {
            par.parcheaza(a2, 2);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            par.parcheaza(b1, 2);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        try {
            par.parcheaza(b2, 2);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }


}
