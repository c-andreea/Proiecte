package CofetariaPaul;

import java.util.ArrayList;

public class Cofetar {

    private int numarPrajituri;
    private int gata;
    ArrayList<Prajituri> listaDePrajituriInCoacere=new ArrayList();
    ArrayList<Prajituri> listaDePrajituriGata= new ArrayList();
private String nume;
private int varsta;

    public Cofetar(String nume, int varsta) {
        this.nume = nume;
        this.varsta = varsta;
}

    public void agregar(Prajituri pra) {
        listaDePrajituriInCoacere.add(pra);
        numarPrajituri++;
}

public void gataPraj(Prajituri pra){
        listaDePrajituriGata.add(pra);
        gata++;
        listaDePrajituriInCoacere.remove(pra);
        numarPrajituri--;
}

public void toPrint(){
        System.out.println("\nnume: " + nume + " varsta: " + varsta);

        for(Prajituri gob :  listaDePrajituriInCoacere)
        {
            System.out.println("\n"+gob.toPrint());

        }
    for(Prajituri gob :  listaDePrajituriGata)
    {
        System.out.println("\n"+gob.toPrint());

    }
}

public void afis(){
    System.out.println("\nNume: " + nume+"\nvarsta: " + varsta);
}

}
