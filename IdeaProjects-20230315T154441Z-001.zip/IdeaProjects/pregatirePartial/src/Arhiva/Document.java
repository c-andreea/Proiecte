package Arhiva;

public abstract class Document {

    public String getDataAarhivaruu() {
        return dataAarhivaruu;
    }

    public int getNrPagini() {
        return nrPagini;
    }

    public String getId() {
        return id;
    }

    public void setDataAarhivaruu(String dataAarhivaruu) {
        this.dataAarhivaruu = dataAarhivaruu;
    }

    public void setNrPagini(int nrPagini) {
        this.nrPagini = nrPagini;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String dataAarhivaruu;
    private int nrPagini;
    private String  id;

    public Document(String dataAarhivaruu, int nrPagini, String id){
        this.dataAarhivaruu = dataAarhivaruu;
        this.nrPagini = nrPagini;
        this.id = id;

    }

    public String toString() {
        return "\nID: "+id+"\ndata arhivarii: " + dataAarhivaruu + "\nNrPagini"+nrPagini;
    }
}
