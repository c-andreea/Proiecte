public class Imperechere {
public static void main(String[] args){

    int varsta=23,sex=1,inaltime=170;
    short info_impachetata;
    info_impachetata=(short) ((((varsta<<1)|sex)<<8)|inaltime);
   int inaltimee = info_impachetata & 0xff;
   int sexx = (info_impachetata >>> 8) & 1;

  int varstaa = (info_impachetata >>> 9) & 0x7f;
    System.out.println("inaltime "+inaltimee+" "+"sex "+sexx+" "+"varsta "+varstaa);
}


}
