public class TestFacebook {
    public static void main(String[] args) {

        FacebookAccount gigel = new FacebookAccount("Gigel", 56, "Beius");
        FacebookAccount costel = new FacebookAccount("Costel", 32, "Albac");
        FacebookAccount angelica = new FacebookAccount("Angelica", 23, "Belis");
        FacebookAccount veronica = new FacebookAccount("Veronica", 40, "Vadu Crisului");
        FacebookAccount lali = new FacebookAccount("Lali", 28, "Albac");
        FacebookAccount mihai = new FacebookAccount("Mihai", 30, "Beius");
        FacebookAccount paulica = new FacebookAccount("Paulica", 31, "Recea");

        gigel.addFriend(angelica);
        gigel.addFriend(costel);
        gigel.addFriend(lali);
        gigel.addFriend(mihai);
        gigel.addFriend(paulica);

        gigel.showFriends();
        System.out.println();

        gigel.filterByLocation("Albac");
        System.out.println();

        gigel.sortByNume();
        System.out.println();

    }
}