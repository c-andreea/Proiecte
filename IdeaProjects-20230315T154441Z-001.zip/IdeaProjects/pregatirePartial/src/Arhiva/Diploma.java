package Arhiva;

public class Diploma extends Document {
    public Diploma(String dataAarhivaruu, int nrPagini, String id) {
        super(dataAarhivaruu, nrPagini, id);
    }
}
