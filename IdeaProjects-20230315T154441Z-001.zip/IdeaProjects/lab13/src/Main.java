import java.awt.*;
import javax.swing.*;

public class Main extends JPanel{

	public static void main(String[] args) {
		Gara Waterloo = new Gara();
		
		Waterloo.addT(new Tren("Berlin",10,1,"AC1"));
		Waterloo.addT(new Tren("Munchen",5,1,"AC2"));
		Waterloo.addT(new Tren("Frankfurt",16,1,"AC3"));
		Waterloo.addT(new Tren("Dusseldorf",10,31,"AC4"));
		Waterloo.addT(new Tren("Koln",13,1,"AC5"));

		System.out.println("Inainte de sortare:_________________");
		Waterloo.afisareLista();
		System.out.println("Dupa sortare:_______________________");
		Waterloo.sortareT();
		Waterloo.afisareLista();
		
		System.out.println("Cautare:");
		Waterloo.cautare("AC1");
		
		JFrame frame = new JFrame ("Colocviu");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 120);
		
		
		GamePanel panel1 = new GamePanel();
		GamePanel panel2 = new GamePanel();

		JLabel l = new JLabel ("Introduceti codul trenul dorit");
		JTextField tf = new JTextField("-COD-");
		panel1.run();
		panel1.add(l);
		panel1.add(tf);
		panel1.setLayout(new FlowLayout());
		
		JButton b1 = new JButton("Cauta");
		b1.addActionListener(new Button1Listener(l,Waterloo,tf));
		
		panel2.add(b1);
		
		JPanel p = new JPanel();
		p.add(panel1);
		p.add(panel2);
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		 
		frame.setContentPane(p);
		frame.setVisible(true);
	}

}
