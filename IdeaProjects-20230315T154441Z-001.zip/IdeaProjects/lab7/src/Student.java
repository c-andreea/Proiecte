public class Student implements Cloneable{

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

   public String nume;
    public Masina masina;

    public Student(String nume, Masina masina) {
        this.nume = nume;
        this.masina = masina;
    }

//    protected Object clone()throws CloneNotSupportedException
//    {
//        return super.clone();
//    }

    @Override
    protected Object clone() throws CloneNotSupportedException
    {
       Student clona = (Student) super.clone();
        clona.masina = (Masina)this.masina.clone();
        return clona;
    }
}
