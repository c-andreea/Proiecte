package GradinaZoo;

import java.util.ArrayList;

public class Ingrijitor {
    public String getNume() {
        return nume;
    }

    public int getVarsta() {
        return varsta;
    }

    private String nume;

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    private int varsta;
    ArrayList<Animale> listaAnimale=new ArrayList<Animale>();

    public void addAnimale(Animale animale){

        listaAnimale.add(animale);
    }
    public Ingrijitor(String name, int varsta)
    {
        this.nume = name;
        this.varsta = varsta;

    }

    public void toDesc(){
        System.out.println("\nNume: "+nume+"\nvarsta: "+varsta+"\n");

    }

}
