
public class DestinatieDorita {
	
	public static boolean DestinatieDorita(String destinatie, Tren a) {
		if(a.getDestinatie().equals(destinatie)) return true;
		return false;
		
	}

}
