package tema3_6;

public interface IStart {

public void start();

public void stop();

}
