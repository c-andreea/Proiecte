import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class Button1Listener implements ActionListener {
	private int count;
	private JLabel l;
	private Gara Waterloo = new Gara();
	private JTextField text;
	
	public Button1Listener(JLabel l, Gara aux, JTextField tf) {
		this.text=tf;
		this.Waterloo = aux;
		this.l=l;
	}

	public void actionPerformed(ActionEvent e) {
		l.setText(Waterloo.cautare(text.getText()+""));
	}
	
}