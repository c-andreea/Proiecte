package examen2019;

public class Main {
   public static void main(String[] args){
       Parcare parcare = new Parcare();
parcare.Parcare();

       Motocicleta m1 = new Motocicleta("Yamaha", 100, " are atas");
       Motocicleta m2 = new Motocicleta("Honda", 100, " nu are atas");
       Motocicleta m3 = new Motocicleta("Suzuki", 100, " are atas");
       Autoturism a1 = new Autoturism("BMW", 100, 1000);
       Autoturism a2 = new Autoturism("Audi", 100, 1000);
       Autoturism a3 = new Autoturism("Mercedes", 100, 1000);

try{
    parcare.adaugare(m1, 0, 0);}

catch(Exception e){
   System.out.println(e.getMessage());
}

       try{
       parcare.adaugare(m2, 0, 1);
       }
       catch(Exception e){
           System.out.println(e.getMessage());
       }

       try{
           parcare.adaugare(a1, 1, 0);
       }
       catch(Exception e){
           System.out.println(e.getMessage());
       }

   }
}
