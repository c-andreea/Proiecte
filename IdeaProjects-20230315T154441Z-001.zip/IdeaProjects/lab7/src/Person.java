import java.lang.reflect.Array;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Person implements Comparable<Person> {
    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    private String nume;
    private String prenume;
    private int varsta;

    public Person(String nume,String prenume,int varsta)
    {
        this.nume=nume;
        this.prenume=prenume;
        this.varsta=varsta;
    }


    @Override
    public int compareTo(Person o) {
        return getNume().compareTo(o.getNume());
    }

    //@Override
  //  public int compareTo(Person p1) {
  //      return varsta- p1.varsta;
  //  }


    public String toString()
    {
        return "Nume: "+nume+"\nPrenume: "+prenume+"\nVarsta: "+varsta;
    }



    public  static void main(String[] args)
    {

        Person p1=new Person("p1","pp",5);
        Person p2=new Person("p2","ppp",6);
        Person p3=new Person("p3","pppp",7);
        int n=3;

        ArrayList<Person> lista=new ArrayList<>();
         lista.add(p1);
         lista.add(p2);
         lista.add(p3);
        Collections.sort(lista);
        System.out.println(lista);

    }
}
