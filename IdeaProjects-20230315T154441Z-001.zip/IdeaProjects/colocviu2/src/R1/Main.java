package R1;

import java.time.LocalTime;
import java.util.Collections;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Gara gara = new Gara("Waterloo Station");

        Tren tren1 = new Tren("Manchester", LocalTime.of(9, 0), "W1M");
        Tren tren2 = new Tren("Liverpool", LocalTime.of(15, 45), "W5L");
        Tren tren3 = new Tren("Bristol", LocalTime.of(12, 15), "W3B");
        Tren tren4 = new Tren("Southampton", LocalTime.of(14, 0), "W4S");

        Tren tren5 = new Tren("Brighton", LocalTime.of(10, 30), "W2B");
        gara.adaugaTren(tren1);
        gara.adaugaTren(tren2);
        gara.adaugaTren(tren3);
        gara.adaugaTren(tren4);
        gara.adaugaTren(tren5);

        Collections.sort(gara.getTrenuri(), new Comparator<Tren>() {
            @Override
            public int compare(Tren t1, Tren t2) {
                return t1.getOraPlecarii().compareTo(t2.getOraPlecarii());
            }
        });

        System.out.println("In gara " + gara.getNume() + " urmeaza sa plece urmatoarele trenuri:");
        for (Tren tren : gara.getTrenuri()) {
            System.out.println("- Trenul cu destinatia " + tren.getDestinatie() + " si codul unic " + tren.getCodUnic() + " pleaca la ora " + tren.getOraPlecarii());
        }
    }


}
