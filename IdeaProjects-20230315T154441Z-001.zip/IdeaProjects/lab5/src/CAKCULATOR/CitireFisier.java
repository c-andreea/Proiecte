package CAKCULATOR;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CitireFisier {
    public static void main(String[] args) throws FileNotFoundException {
        File file=new File("C:\\Users\\andre\\IdeaProjects\\lab5\\src\\CAKCULATOR\\Numere.txt");
        Scanner scan=new Scanner(file);
        while(scan.hasNextLine())
        System.out.println(scan.nextLine());

    }
}
