package Farmacia;

public class MedicamentInexistentException extends Exception {
    public MedicamentInexistentException(String message) {
        super(message);
    }
    }

