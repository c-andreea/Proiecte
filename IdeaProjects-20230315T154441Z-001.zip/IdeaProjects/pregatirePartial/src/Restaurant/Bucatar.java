package Restaurant;

import java.util.ArrayList;

public class Bucatar {



private final int NUMAR_MAXIM=4;
private int numarPreparat;
    public String nume;
    public int vechime;
    public String adresa;

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setVechime(int vechime) {
        this.vechime = vechime;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }



    public String getNume() {
        return nume;
    }

    public int getVechime() {
        return vechime;
    }

    public String getAdresa() {
        return adresa;
    }


    ArrayList<Preparat> listaPrearatInCurs=new ArrayList<>();

    public Bucatar(String nume,int vechime,String adresa){
        this.nume=nume;
        this.vechime=vechime;
        this.adresa=adresa;

    }

    public void adaugaPreparat(Preparat preparat){
        if(numarPreparat+1<=NUMAR_MAXIM)
        {
            listaPrearatInCurs.add(preparat);
numarPreparat++;

        }
    }

    public void serveste(Preparat preparat){
        if(numarPreparat>0) {
            listaPrearatInCurs.remove(preparat);
            numarPreparat--;
        }
    }

    public void toPrint(){
        System.out.println("\nnume: " + nume+"\nVechime"+vechime+"\nstrada: " +adresa);
        for(Preparat preparat:listaPrearatInCurs){
            System.out.println("\n preparat in pregatire "+preparat.name);
}    }
}
