package examen2020;

public class Autoturism extends Autovehicule {
    public int getCaiPutere() {
        return caiPutere;
    }

    private int caiPutere;
    private boolean sport;
  public Autoturism(String marca, int masa, int caiPutere, boolean sport) {
            super(marca, masa);
            this.caiPutere = caiPutere;
            this.sport = sport;
        }

    public boolean isSport() {
        return sport;
    }

    public String toString() {
        return "Autoturism: "+super.toString()+" nr. cai: "+caiPutere +" este sport: "+ sport;
    }



}



