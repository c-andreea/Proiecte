package examen2019;

public class Autoturism extends Autovehicul {
    private int km;

    public Autoturism(String marca, int caiPutere, int km) {
        super(marca, caiPutere);

    }
    public String toString(){
        return super.toString() + "Km: " + km;
    }
}

