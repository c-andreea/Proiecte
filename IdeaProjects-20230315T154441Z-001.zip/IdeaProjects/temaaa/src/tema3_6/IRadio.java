package tema3_6;

public interface IRadio extends IStart,IBluetooth{
    void up();
    void down();
}
