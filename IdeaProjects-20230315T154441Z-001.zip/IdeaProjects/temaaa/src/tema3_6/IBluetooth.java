package tema3_6;

public interface IBluetooth {
    void connect();
    void disconnect();
}
