package Farmacia;



import java.util.ArrayList;
import java.util.List;

public class Farmacie {
    public String getNume() {
        return nume;
    }

    public String getAdresa() {
        return adresa;
    }

    private String nume;
private String adresa;
private ArrayList<Medicament> medicamente;

public Farmacie(String nume, String adresa) {
        this.nume = nume;
        this.adresa = adresa;
        this.medicamente = new ArrayList<Medicament>();
        }

public void adaugaMedicament(Medicament medicament) {
        this.medicamente.add(medicament);
        }

public ArrayList<Medicament> getMedicamente() {
        return this.medicamente;
        }


    public Medicament cautaMedicament(String cod) throws MedicamentInexistentException {
        for (Medicament medicament : medicamente) {
            if (medicament.getCodUnic().equals(cod)) {
                return medicament;
            }
        }
        throw new MedicamentInexistentException("Medicamentul cu codul " + cod + " nu a fost gasit in farmacie.");
    }
        }