
public class Autoturism extends Autovehicul{
	private int nrCai;
	private boolean sport;
	
	public Autoturism(String marca, int masa, int nrCai, boolean sport)
	{
		super(marca,masa);
		this.nrCai = nrCai;
		this.sport=sport;
	}
	
	public boolean isSport() {
		return sport;
	}
	
	public String toString() {
		return "Autoturism: "+super.toString()+" nr. cai: "+nrCai +" este sport: "+ sport;
	}
}
