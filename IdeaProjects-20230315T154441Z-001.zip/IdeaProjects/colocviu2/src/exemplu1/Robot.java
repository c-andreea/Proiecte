package exemplu1;

class Robot extends Angajati {
    public Robot(String nume, int varsta) {
        super(nume, varsta, "robot");
    }
}
