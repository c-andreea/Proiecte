package exemplu1;

class Piloti {
    private String nume;
    private String prenume;
    private int varsta;
    private String grad;

    public Piloti(String nume, String prenume, int varsta, String grad) {
        this.nume = nume;
        this.prenume = prenume;
        this.varsta = varsta;
        this.grad = grad;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }
}

