package Farmacia;


import java.util.*;

public class Main {
    public static void main(String[] args) {
        Date dataExpirare1 = new Date(2022, 01, 01);
        Date dataExpirare2 = new Date(2022, 02, 01);
        Date dataExpirare3 = new Date(2022, 03, 01);
        Date dataExpirare4 = new Date(2022, 04, 01);
        Date dataExpirare5 = new Date(2022, 05, 01);
        Date dataFab1 = new Date(01,01,2021);
        Date dataFab2 = new Date(01,01,2021);
        Date dataFab3 = new Date(01,01,2021);
        Date dataFab4 = new Date(01,01,2021);
        Date dataFab5 = new Date(01,01,2021);

        List<String> ingrediente = Arrays.asList("ing1", "ing2", "ing3");
        Farmacie farmacie = new Farmacie("Catena", "Str. Stefan cel Mare nr. 15");
        Medicament paracetamol = new Medicament("Paracetamol", dataExpirare1, 5.50, dataFab1, "A1B2C3",ingrediente);
        Medicament ibuprofen = new Medicament("Ibuprofen", dataExpirare2, 7.50, dataFab2, "D4E5F6",ingrediente);
        Medicament Algocalmin = new Medicament("Algocalmin", dataExpirare3, 12.00, dataFab3, "G7H8I9",ingrediente);
        Medicament colebil = new Medicament("Colebil", dataExpirare4, 20.00, dataFab4, "J1K2L3",ingrediente);
        Medicament zinc = new Medicament("Zinc", dataExpirare5, 15.50, dataFab5, "M4N5O6",ingrediente);
        farmacie.adaugaMedicament(paracetamol);
        farmacie.adaugaMedicament(ibuprofen);
        farmacie.adaugaMedicament(colebil);
        farmacie.adaugaMedicament(zinc);


        System.out.println("Bine ati venit la farmacia " + farmacie.getNume() + " din " + farmacie.getAdresa() + "!");
        System.out.println("Medicamentele disponibile sunt:");
        for (Medicament medicament : farmacie.getMedicamente()) {
            System.out.println("- " + medicament.getNume() + ", pret: " + medicament.getPret() + " lei, cod unic: " + medicament.getCodUnic());
        }
        farmacie.adaugaMedicament(Algocalmin);
        System.out.println("\n\n");
        Collections.sort(farmacie.getMedicamente(), new Comparator<Medicament>() {
            @Override
            public int compare(Medicament m1, Medicament m2) {
                return m1.getNume().compareTo(m2.getNume());
            }
        });

        System.out.println("Medicamentele din farmacie in ordine alfabetica:");
        for (Medicament medicament : farmacie.getMedicamente()) {
            System.out.println("- " + medicament.getNume()+ ", pret: " + medicament.getPret() + " lei, cod unic: " + medicament.getCodUnic()+ ", data expirare: " + medicament.getDataExpirare()+ ", data fabricatie: " + medicament.getDataFabricatie()+ ", ingrediente: " + medicament.getIngrediente());
        }


        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduceti numele clientului: ");
        String numeClient = scanner.nextLine();
        Client client = new Client(numeClient);
        System.out.print("Introduceti numarul de bucati doMrit pentru medicamentul Paracetamol: ");
        int cantitateParacetamol = scanner.nextInt();
        System.out.print("Introduceti numarul de bucati dorit pentru medicamentul Ibuprofen: ");
        int cantitateIbuprofen = scanner.nextInt();
        System.out.print("Introduceti numarul de bucati dorit pentru medicamentul Algocalmin: ");
        int cantitateVitaminaC = scanner.nextInt();
        client.adaugaMedicament(paracetamol, cantitateParacetamol);
        client.adaugaMedicament(ibuprofen, cantitateIbuprofen);
        client.adaugaMedicament(Algocalmin, cantitateVitaminaC);
        double total = cantitateParacetamol * paracetamol.getPret() + cantitateIbuprofen * ibuprofen.getPret() + cantitateVitaminaC * Algocalmin.getPret();
        System.out.println("Clientul " + client.getNume() + " a cumparat urmatoarele medicamente:");
        for (Medicament medicament : client.getCumparaturi()) {
            System.out.println("- " + medicament.getNume());
        }
        System.out.println("Total de plata: " + total + " lei.");
        System.out.println("Multumim pentru cumparaturi! La revedere!");
    }
}
