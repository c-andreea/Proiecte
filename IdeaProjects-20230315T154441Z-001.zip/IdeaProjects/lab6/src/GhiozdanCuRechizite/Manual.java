package GhiozdanCuRechizite;

public class Manual extends Rechizite{
    public Manual(String eticheta) {
        super(eticheta);
    }

    public String getNume()
    {

        return "Manual: "+eticheta;
    }
    }



