import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class SpaceInvaders extends JPanel implements KeyListener, Runnable {
    private static final long serialVersionUID = 1L;

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;

    private Thread thread;
    private boolean running;

    private boolean right = true;
    private boolean left = false;
    private boolean up = false;
    private boolean down = false;

    private ArrayList<Entity> entities;
    private ArrayList<Entity> remove;

    private Entity player;
    private int score;

    public SpaceInvaders() {
        super();

        setFocusable(true);
        requestFocus();
        addKeyListener(this);

        entities = new ArrayList<Entity>();
        remove = new ArrayList<Entity>();

        player = new Player(WIDTH / 2 - 50, HEIGHT - 100, 100, 100, this);
        entities.add(player);

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {
                entities.add(new Enemy(j * 75, i * 75, 75, 75, this));
            }
        }
    }

    public void tick() {
        for (int i = 0; i < entities.size(); i++) {
            Entity e = entities.get(i);
            e.tick();
        }
    }

    public void render(Graphics g) {
        g.clearRect(0, 0, WIDTH, HEIGHT);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        for (int i = 0; i < entities.size(); i++) {
            Entity e = entities.get(i);
            e.render(g);
        }
    }

    public void start() {
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    public void stop() {
        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (running) {
            tick();
            repaint();
            try {
                Thread.sleep(1000 / 60);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SpaceInvaders game = new SpaceInvaders();

        JFrame frame = new JFrame("Space Invaders");
        frame.add(game);
        frame.setSize(WIDTH, HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);

        game.start();
    }

    public void addEntity(Entity e) {
        entities.add(e);
    }

    public void removeEntity(Entity e) {
        remove.add(e);
    }

    public void cleanUp() {
        entities.removeAll(remove);
        remove.clear();
    }

    public void setRight(boolean right) {
        this.right = right;
    }

    public void setLeft(boolean left) {
        this.left = left;
    }

    public void setUp(boolean up) {
        this.up = up;
    }

    public void setDown(boolean down) {
        this.down = down;
    }

    public boolean isRight() {
        return right;
    }

    public boolean isLeft() {
        return left;
    }

    public boolean isUp() {
        return up;
    }

    public boolean isDown() {
        return down;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_RIGHT) {
            setRight(true);
        } else if (key == KeyEvent.VK_LEFT) {
            setLeft(true);
        } else if (key == KeyEvent.VK_UP) {
            setUp(true);
        } else if (key == KeyEvent.VK_DOWN) {
            setDown(true);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_RIGHT) {
            setRight(false);
        } else if (key == KeyEvent.VK_LEFT) {
            setLeft(false);
        } else if (key == KeyEvent.VK_UP) {
            setUp(false);
        } else if (key == KeyEvent.VK_DOWN) {
            setDown(false);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }
}

abstract class Entity {
    protected double x;
    protected double y;
    protected int width;
    protected int height;
    protected SpaceInvaders game;
    protected boolean active = true;

    public Entity(double x, double y, int width, int height, SpaceInvaders game) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.game = game;
    }

    public abstract void tick();

    public abstract void render(Graphics g);

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x ;   }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}

class Player extends Entity {
    public Player(double x, double y, int width, int height, SpaceInvaders game) {
        super(x, y, width, height, game);
    }

    @Override
    public void tick() {
        if (game.isRight()) {
            setX(getX() + 5);
        } else if (game.isLeft()) {
            setX(getX() - 5);
        } else if (game.isUp()) {
            setY(getY() - 5);
        } else if (game.isDown()) {
            setY(getY() + 5);
        }
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect((int) getX(), (int) getY(), getWidth(), getHeight());
    }
}

class Enemy extends Entity {
    private Random random;

    public Enemy(double x, double y, int width, int height, SpaceInvaders game) {
        super(x, y, width, height, game);
        random = new Random();
    }

    @Override
    public void tick() {
        setX(getX() + random.nextInt(5) - 2);
        setY(getY() + random.nextInt(5) - 2);
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect((int) getX(), (int) getY(), getWidth(), getHeight());
    }
}

