package NumereComplexe;
import java.util.Random;
import java.util.Scanner;

public class Matrice {
    private int numarDeLinii;
    private int numarDeColoane;
    private Complex[][] array;
    Random random= new Random();


  public Matrice(int numarDeColoane,int numarDeLinii)
  {this.numarDeColoane=numarDeColoane;
      this.numarDeLinii=numarDeLinii;
  array=new Complex[numarDeLinii][numarDeColoane];
  for(int i=0;i<numarDeLinii;i++)
      for(int j=0;j<numarDeColoane;j++){
          array[i][j]=new Complex(random.nextInt(10), random.nextInt(10));

      }


  }

  public Complex getPozitie(int i,int j)
  {
      return array[i][j];
  }

  public void afisareMatrice()
  {for(int i=0;i<numarDeLinii;i++) {
      for (int j = 0; j < numarDeColoane ; j++) {
          System.out.print(array[i][j] + " ");

      }
      System.out.println("");
  }
  }

  public void adunaMatrice(Matrice d){
      for(int i=0;i<numarDeLinii;i++){
          for(int j=0;j<numarDeColoane;j++){
           array[i][j]= array[i][j].aduna(d.getPozitie(i,j));
//
          }}
  }
    public void scadMatrice(Matrice d){
        for(int i=0;i<numarDeLinii;i++){
            for(int j=0;j<numarDeColoane;j++){
               array[i][j]= array[i][j].scadere(d.getPozitie(i,j));

            }}
    }

  public void inmultireScalar(int numar){
      for(int i=0;i<numarDeLinii;i++){
          for(int j=0;j<numarDeColoane;j++){
array[i][j]=array[i][j].inmultire(numar);

          }}
  }
    public static void main(String[] args)
    {
        Matrice a= new Matrice(4,4);
        Matrice b=new Matrice(4,4);
        Matrice c=new Matrice(4,4);
        Matrice d=new Matrice(4,4);
        Matrice e=new Matrice(4,4);
        Matrice f=new Matrice(4,4);
       // Matrice Suma=new Matrice(4,4);
//a.afisareMatrice();
   //     System.out.println("");
//b.afisareMatrice();
     //   System.out.println("");
        e.afisareMatrice();;
        System.out.println("");
        f.afisareMatrice();
//
     //   System.out.println("");
        System.out.println("");
     //   System.out.println("");
   //  b.inmultireScalar(5);
    //    b.afisareMatrice();
     //   System.out.println("");
     //   System.out.println("");
     //   System.out.println("");

           c.scadMatrice(d);

c.afisareMatrice();


    }

}
