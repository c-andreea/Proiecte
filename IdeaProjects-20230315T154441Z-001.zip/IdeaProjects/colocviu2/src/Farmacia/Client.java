package Farmacia;

import java.util.ArrayList;

public class  Client {
    private String nume;
    private ArrayList<Medicament> cumparaturi;

    public Client(String nume) {
        this.nume = nume;
        this.cumparaturi = new ArrayList<Medicament>();
    }

    public void adaugaMedicament(Medicament medicament, int cantitate) {
        for (int i = 0; i < cantitate; i++) {
            this.cumparaturi.add(medicament);
        }
    }

    public ArrayList<Medicament> getCumparaturi() {
        return this.cumparaturi;
    }

    public String getNume() {
        return this.nume;
    }
}