package pob6_1;

public class ExceptieZiNelucratoare  extends Exception {

    public ExceptieZiNelucratoare () {}
    public ExceptieZiNelucratoare(String msg)
    {
        super(msg);
    }

}
