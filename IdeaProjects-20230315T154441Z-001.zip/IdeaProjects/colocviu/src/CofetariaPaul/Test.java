package CofetariaPaul;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String numeCofetaria = scanner.nextLine();
        System.out.println(numeCofetaria+"\n================================");

        Eclere ecler1=new Eclere("Ecler1",12,20,"ciocolata");
        Eclere ecler2=new Eclere("Ecler2",13,21,"vanilie");
        PrajituraMere prajituraMere1=new PrajituraMere("Prajitura",26,30,PrajituraMere.Sos.DA);
        PrajituraMere prajituraMere2=new PrajituraMere("PrajituraMere",30,35,PrajituraMere.Sos.NU);
        Tort tort1=new Tort("Tort",50,60,"alba");
        Tort tort2=new Tort("Tort2",60,70, "neagra");

        Cofetaria cofetaria1=new Cofetaria();


Ingredient ingredient1=new Ingredient("oua",2);
Ingredient ingredient2=new Ingredient("faina",3);

ecler1.addIngredient(ingredient1);
ecler2.addIngredient(ingredient1);
ecler2.addIngredient(ingredient2);
ecler1.addIngredient(ingredient2);
prajituraMere1.addIngredient(ingredient1);
prajituraMere1.addIngredient(ingredient2);
prajituraMere2.addIngredient(ingredient1);
prajituraMere2.addIngredient(ingredient2);
tort1.addIngredient(ingredient1);
tort1.addIngredient(ingredient2);
tort2.addIngredient(ingredient1);
tort2.addIngredient(ingredient2);



        cofetaria1.addPrajit(ecler1);
        cofetaria1.addPrajit(ecler2);
        cofetaria1.addPrajit(tort1);
        cofetaria1.addPrajit(tort2);
        cofetaria1.addPrajit(prajituraMere1);
        cofetaria1.addPrajit(prajituraMere2);

        cofetaria1.toPrint();

        Cofetar cofetar= new Cofetar("Ion",20);
        cofetar.agregar(ecler1);
        cofetar.agregar(ecler2);
        cofetar.toPrint();

        ecler1.coacere(20,cofetar,ecler1);

        Client client1=new Client("1");

client1.cumpara1(ecler1);
client1.cumpara1(ecler2);
client1.cumpara1(prajituraMere2);

    client1.toPtint();

    Client client2=new Client("2");
    client2.cumpara1(tort1);
    client2.cumpara1(ecler2);
        client2.toPtint();



    }
}
