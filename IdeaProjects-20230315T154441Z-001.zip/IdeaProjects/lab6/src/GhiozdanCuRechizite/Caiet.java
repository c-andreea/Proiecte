package GhiozdanCuRechizite;

public class Caiet extends Rechizite{

    public Caiet(String eticheta) {
        super(eticheta);
    }

    public String getNume() {

        return "Caiet: "+eticheta;
    }

}
