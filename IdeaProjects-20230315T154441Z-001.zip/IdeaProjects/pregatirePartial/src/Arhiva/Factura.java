package Arhiva;

public class Factura extends Document{
    public Factura(String dataAarhivaruu, int nrPagini, String id,int nrLinii, int nrColumna,String achizitii) {
        super(dataAarhivaruu, nrPagini, id);
        this.nrLinii=nrLinii;
        this.nrColumna=nrColumna;
        this.achizitii=new String[nrLinii][nrColumna];

    }
    private int nrLinii;
    private int nrColumna;

    private String[][] achizitii;


}
