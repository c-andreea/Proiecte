package examen2022;

import java.util.ArrayList;

public class Zone {
    private int numarLocuri;

    public ArrayList<Vehicule> getList() {
        return list;
    }

    private ArrayList<Vehicule> list = new ArrayList<>();
    private int nrLocuriDisponibile=0;
private int nrBiciclete;

    public Zone(int numarLocuri){
        this.numarLocuri = numarLocuri;

    }
 public void addVehicule(Vehicule x) throws Exception{
     if(nrLocuriDisponibile<=numarLocuri){
         list.add(x);
         nrLocuriDisponibile++;
     }
     else {throw new Exception("Nu mai sunt locuri");}
 }

 public void nrBiciclete(int an) {
        nrBiciclete=0;
        for(Vehicule x : list){
            if(x instanceof Biciclete)
            {
                if(x.getAn()==an){
                    nrBiciclete++;
                }
            }
        }
     System.out.println("Numarul de biciclete este: "+nrBiciclete);

 }



}
