package CofetariaPaul;

public class PrajituraMere extends Prajituri {
    public PrajituraMere(String name, int pret, int timpCoacere,Sos sos) {
        super(name, pret, timpCoacere);
        this.sos = sos;

    }

    boolean vanilie;
    enum Sos{
        DA,
        NU;
    }
    Sos sos;

    public void contineSos(){this.sos=Sos.DA;}
    public void nuContineSos(){this.sos=Sos.NU;}

    @Override
    public void coacere(int timp,Cofetar cofetar,Prajituri pra) {
        if(timp==timpCoacere)
        {
            System.out.println("\ngata prajitura");
            cofetar.gataPraj(pra);

        }
       else if(timp<=timpCoacere)
        {
            System.out.println("\nnu este gata");
        }
       else
        {
            System.out.println("\ns-a ars prajitura");
            cofetar.gataPraj(pra);

        }

    }

    public String toPrint(){
        switch (this.sos) {
            case DA:
                return super.toPrint()+"\nPrajitura contine sos de vanilie";
            case NU:
                return super.toPrint()+"\nPrajitura nu contine sos de vanilie";
            default:
                return "";
        }
    }

}
