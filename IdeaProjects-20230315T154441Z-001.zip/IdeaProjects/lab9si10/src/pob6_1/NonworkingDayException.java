package pob6_1;

public class NonworkingDayException extends Exception {
    public NonworkingDayException(String message) {
        super(message);
    }
}
