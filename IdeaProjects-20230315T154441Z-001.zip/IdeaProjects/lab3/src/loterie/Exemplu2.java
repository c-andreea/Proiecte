package loterie;

import java.math.BigInteger;



public class Exemplu2 {

    public static BigInteger calculFactorial(int n)
    {
BigInteger valInitiala= new BigInteger("1");
BigInteger rezultat=BigInteger.valueOf(1);

 for(int i=1;i<=n;i++){
     rezultat=rezultat.multiply(BigInteger.valueOf(i));}

   return rezultat;
    }

    public static void main(String[] args)
    {
        int n=6;
        BigInteger val1=calculFactorial(6);
        BigInteger val2=calculFactorial(49);
        BigInteger val3=calculFactorial(43);

        BigInteger rezultat=val2.divide(val1.multiply(val3));
        System.out.println(rezultat);
    }

}
