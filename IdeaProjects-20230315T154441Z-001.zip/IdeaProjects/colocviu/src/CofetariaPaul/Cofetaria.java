package CofetariaPaul;

import java.util.ArrayList;

public class Cofetaria {
    ArrayList<Prajituri>listaPrajit = new ArrayList();
    public int numero=0;
    public int pretTotal=0;

    public void addPrajit(Prajituri pra){
        listaPrajit.add(pra);
        numero++;

    }
    public void cumpara(Prajituri pra)
    {
        pretTotal+=pra.pret;
    }



    public void toPrint(){
        System.out.println("\nnumar de prajituri existente: " + numero);
        for(Prajituri pra : listaPrajit){
            if(pra instanceof Eclere){
                System.out.println(pra.toPrint());

            }
            if(pra instanceof Tort){
                System.out.println(pra.toPrint());

            }
            if(pra instanceof PrajituraMere){
                System.out.println(pra.toPrint());

}
        }

    }

}
