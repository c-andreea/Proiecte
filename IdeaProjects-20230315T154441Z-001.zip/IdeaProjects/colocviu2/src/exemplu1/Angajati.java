package exemplu1;

class Angajati {
    private String nume;
    private int varsta;
    private String tip;

    public Angajati(String nume, int varsta, String tip) {
        this.nume = nume;
        this.varsta = varsta;
        this.tip = tip;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public void mananca() {
        System.out.println(nume + " mananca.");
    }

    public void doarme() {
        System.out.println(nume + " doarme.");
    }

    public void facePauza() {
        System.out.println(nume + " face pauza.");
    }

    public void lucreaza() {
        System.out.println(nume + " lucreaza.");}
}

