package examen2020;

public abstract class Autovehicule {
    private String marca;
    private int masa;
    public Autovehicule(String marca, int masa) {
        this.marca = marca;
        this.masa = masa;
    }
}
