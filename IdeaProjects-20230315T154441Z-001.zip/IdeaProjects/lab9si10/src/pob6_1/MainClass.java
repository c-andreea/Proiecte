package pob6_1;

public class MainClass {
    public static void main(String[] args) {
        CalendarWork calendar = new CalendarWork();
        Worker worker = new Worker("Gigel", calendar);
        try {
            worker.work("Monday");
            worker.work("Mars");
            worker.work("Sunday");
        } catch (NonworkingDayException e) {
            System.out.println(e.getMessage());
        }
    }
}