package examen2019;

import java.util.Scanner;

public class Parcare {
    private int nrLocuriRanduri;
    private int nrLocuriColoane;
    private String[][] locuri=new String[nrLocuriRanduri][nrLocuriColoane];
    private int nrLocuriOcupate;
    private int nrLocuri;

    private int pozRand;
    private int pozColoana;
    Scanner sc = new Scanner(System.in);


    public void Parcare() {
        System.out.println("Introduceti numarul de randuri: ");
        nrLocuriRanduri = sc.nextInt();
        System.out.println("Introduceti numarul de coloane: ");
        nrLocuriColoane = sc.nextInt();
        nrLocuri = nrLocuriColoane * nrLocuriRanduri;
        for (int i = 0; i <= nrLocuriRanduri; i++) {
            for (int j = 0; j <= nrLocuriColoane; j++) {
                locuri[i][j] = "Liber";
            }
        }



    }

    public void adaugare(Autovehicul x,int pozRand, int pozColoana) throws Exception {
        if(x instanceof Motocicleta){
        if (locuri[pozRand][pozColoana]=="Liber") {
            locuri[pozRand][pozColoana] = x.toString();
            nrLocuriOcupate++;
        } else {
            throw new Exception("Locul este ocupat!");
        }}
        else{
            if(locuri[pozRand][pozColoana]=="Liber"){
                locuri[pozRand][pozColoana] = x.toString();
                locuri[pozRand][pozColoana+1] = x.toString();
                nrLocuriOcupate++;
            }
            else{
                throw new Exception("Locul este ocupat!");
            }
        }


    }

    public void scoate(Autovehicul x, int pozRand, int pozColoana) {
        if (locuri[pozRand][pozColoana]!="Liber") {
            locuri[pozRand][pozColoana] = "0";
            nrLocuriOcupate--;
        }
    }

    public void autoturismePeRand(int rand) {
        int nrAutoturisme = 0;
        for (int i = 0; i < nrLocuriColoane; i++) {
            if (locuri[rand][i]!="0") {
                nrAutoturisme++;
            }
        }
        System.out.println("Numarul de autoturisme pe randul " + rand + " este: " + nrAutoturisme);
    }
    public void MotocicleteFaraAtas(){
        int nrMotocicleteFaraAtas=0;
        for(int i=0;i<nrLocuriRanduri;i++){
            for(int j=0;j<nrLocuriColoane;j++){
                if(locuri[i][j].indexOf(" are atas")==1){
                    nrMotocicleteFaraAtas++;
                }
            }
        }
        System.out.println("Numarul de motociclete fara atas este: "+nrMotocicleteFaraAtas);
    }

}
