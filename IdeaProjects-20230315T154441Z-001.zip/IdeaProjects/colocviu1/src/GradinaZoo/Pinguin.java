package GradinaZoo;

public class Pinguin extends Animale{
    public Pinguin(String name, String culoare, int varsta,int nrPasi) {
        super(name, culoare, varsta);
        this.nrPasi = nrPasi;

    }
    private int nrPasi;

    @Override
    public void mananca(Mancare mancare) {
        System.out.println("\n Pingu a fost hranit"+mancare.toString());
    }
public void plimbare(int pasi){
        nrPasi +=pasi;
    System.out.println("Pingu a mai mers"+nrPasi);
}
    public String toPrint(){
        return super.toPrint() + "\nNrPasi: " + nrPasi;
    }
}
