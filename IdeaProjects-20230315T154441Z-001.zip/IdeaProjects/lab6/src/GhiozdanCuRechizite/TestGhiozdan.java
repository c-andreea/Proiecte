package GhiozdanCuRechizite;

public class TestGhiozdan {
    public static void main(String[] args){

        Manual manual1= new Manual("mate");
        Caiet caiet1= new Caiet("caiet mate");

        System.out.println(manual1.getNume());
        System.out.println(caiet1.getNume());

        Ghiozdan ghiozdan1=new Ghiozdan();
        ghiozdan1.add(manual1);
        ghiozdan1.add(caiet1);
        ghiozdan1.afisare();
        ghiozdan1.afisareCaiet();
    }
}
