package tema3_6;

public class Functii implements IStart {

    public String name;

    public Functii(String name) {
        this.name = name;
    }

    @Override
    public void start() {
        System.out.println("Functia "+name+" a fost pornita");

    }

    @Override
    public void stop() {
        System.out.println("Functia "+name+" a fost oprita");
    }
}
