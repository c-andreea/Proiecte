package AeroportulK;

public abstract class Aeronava {
 public String nume;
public String numePilot;
public int nrPasageri;
//private String stareActuala;
public int nivelComvustibil;
enum Stare{
    ATERIZAT,
    DECOLAT;
}
    public int getNrPasageri() {
        return nrPasageri;
    }

    public void setNrPasageri(int nrPasageri) {
        this.nrPasageri = nrPasageri;
    }
    public void decolare() {
        this.stare = Stare.DECOLAT;
    }

    public void aterizat() {
        this.stare = Stare.ATERIZAT;
    }

    public Stare stare;

    public String getTipAeronava() {
        return tipAeronava;
    }

    public String getNume() {
        return nume;
    }

    public String getNumePilot() {
        return numePilot;
    }

   public String tipAeronava;



    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setNumePilot(String numePilot) {
        this.numePilot = numePilot;
    }



    public Aeronava(String nume,String numePilot,int nrPasageri,int nivelComvustibil, Stare stare)
{
    this.stare=stare;
    this.nume=nume;
    this.numePilot=numePilot;
    this.nrPasageri=nrPasageri;
    this.nivelComvustibil=nivelComvustibil;
  //  this.stareActuala=stareActuala;
}

public void alimentare(int cantitate){
        this.nivelComvustibil+= cantitate;
}


public String getDesc(){
       return "numele aeronavei este: "+ nume+ "\nnumele pilotului este: "+ numePilot+ "\nnivelul de comvustib este: "+nivelComvustibil+
              "\nStare: "+ stare+ "\nNr. Pasageri: "+ nrPasageri;

}


}
